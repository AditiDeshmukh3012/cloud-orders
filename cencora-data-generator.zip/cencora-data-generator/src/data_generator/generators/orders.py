"""Orders table: valid orders plus a controlled minority of bad order records.

Every valid order is assigned a scenario (on_time / late / open / cancelled)
using exact counts. The scenario drives how shipments and delivery events are
generated later, but it is NOT written to the CSV.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta

import pandas as pd

from data_generator.config import ORDERS_COLUMNS, GeneratorConfig
from data_generator.manifest import MISSING_ORDER_ID, REJECT, UNKNOWN_PHARMACY, entry
from data_generator.utils.counts import allocate_counts, rate_count
from data_generator.utils.ids import order_id, pharmacy_id
from data_generator.utils.random_utils import format_ts, make_rng, random_datetime

BATCH_1 = "batch_001"

# Scenarios for valid orders
ON_TIME = "on_time"
LATE = "late"
OPEN = "open"
CANCELLED = "cancelled"
VALID_SCENARIOS = (ON_TIME, LATE, OPEN, CANCELLED)

# Scenarios for dedicated invalid-record orders (reserved ID range)
UNKNOWN_PHARMACY_ORDER = "unknown_pharmacy"
BAD_QUANTITY_ORDER = "bad_quantity"
MISSING_LINE_ID_ORDER = "missing_line_id"

INVALID_ORDER_START = 900000  # invalid-record orders are ORD-900001 and up
LEAD_TIME_HOURS = [48, 72, 96, 120]

STATUS_BY_SCENARIO = {
    ON_TIME: "COMPLETED",
    LATE: "OPEN",  # still open at the batch_001 load; completes in a later batch
    OPEN: "OPEN",
    CANCELLED: "CANCELLED",
}


@dataclass
class OrdersResult:
    """Orders table plus the internal scenario map and test manifest entries."""

    orders: pd.DataFrame
    scenarios: dict[str, str]  # order_id -> scenario (internal only)
    manifest: list[dict[str, str]]


def _make_row(oid: str, pharmacy: str, order_time: datetime, lead_hours: int, status: str) -> dict[str, str]:
    return {
        "order_id": oid,
        "pharmacy_id": pharmacy,
        "order_time": format_ts(order_time),
        "promised_delivery_time": format_ts(order_time + timedelta(hours=lead_hours)),
        "order_status": status,
    }


def _random_row(rng: random.Random, config: GeneratorConfig, oid: str, pharmacy: str, status: str) -> dict[str, str]:
    order_time = random_datetime(rng, config.start_dt, config.end_dt)
    return _make_row(oid, pharmacy, order_time, rng.choice(LEAD_TIME_HOURS), status)


def _unknown_pharmacy_id(known: set[str], k: int) -> str:
    """A pharmacy ID guaranteed not to exist in the pharmacies table."""
    n = 9000 + k
    while pharmacy_id(n) in known:
        n += 1
    pid = pharmacy_id(n)
    known.add(pid)
    return pid


def generate_orders(config: GeneratorConfig, pharmacy_ids: list[str]) -> OrdersResult:
    """Generate valid orders and controlled invalid order records."""
    if config.orders >= INVALID_ORDER_START:
        raise ValueError(f"orders must be below {INVALID_ORDER_START}")

    rng = make_rng(config.seed, "orders")
    rows: list[dict[str, str]] = []
    scenarios: dict[str, str] = {}
    manifest: list[dict[str, str]] = []

    # --- valid orders: exact scenario counts, shuffled, with ascending order times
    counts = allocate_counts(
        config.orders,
        {
            ON_TIME: config.on_time_pct,
            LATE: config.late_pct,
            OPEN: config.open_pct,
            CANCELLED: config.cancelled_pct,
        },
    )
    plan = [s for s in VALID_SCENARIOS for _ in range(counts[s])]
    rng.shuffle(plan)
    times = sorted(random_datetime(rng, config.start_dt, config.end_dt) for _ in range(config.orders))
    for i, (scenario, order_time) in enumerate(zip(plan, times), start=1):
        oid = order_id(i)
        pharmacy = rng.choice(pharmacy_ids)
        rows.append(_make_row(oid, pharmacy, order_time, rng.choice(LEAD_TIME_HOURS), STATUS_BY_SCENARIO[scenario]))
        scenarios[oid] = scenario

    # --- invalid: orders referencing an unknown pharmacy
    next_no = INVALID_ORDER_START
    known = set(pharmacy_ids)
    for k in range(rate_count(config.orders, config.unknown_pharmacy_pct)):
        next_no += 1
        oid = order_id(next_no)
        rows.append(_random_row(rng, config, oid, _unknown_pharmacy_id(known, k), "OPEN"))
        scenarios[oid] = UNKNOWN_PHARMACY_ORDER
        manifest.append(entry("orders", BATCH_1, oid, UNKNOWN_PHARMACY, REJECT))

    # --- valid orders that exist only to carry one bad order line each
    for kind, rate in (
        (BAD_QUANTITY_ORDER, config.nonpositive_quantity_pct),
        (MISSING_LINE_ID_ORDER, config.missing_id_pct),
    ):
        for _ in range(rate_count(config.orders, rate)):
            next_no += 1
            oid = order_id(next_no)
            rows.append(_random_row(rng, config, oid, rng.choice(pharmacy_ids), "OPEN"))
            scenarios[oid] = kind

    # --- invalid: order rows with a missing order_id
    for _ in range(rate_count(config.orders, config.missing_id_pct)):
        row = _random_row(rng, config, "", rng.choice(pharmacy_ids), "OPEN")
        rows.append(row)
        key = f"|{row['pharmacy_id']}|{row['order_time']}"
        manifest.append(entry("orders", BATCH_1, key, MISSING_ORDER_ID, REJECT))

    return OrdersResult(pd.DataFrame(rows, columns=ORDERS_COLUMNS), scenarios, manifest)
