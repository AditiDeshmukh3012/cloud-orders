"""Delivery events: incremental delivered quantities, split across batches.

Each valid shipment line produces exactly one valid delivery event whose
delivered_quantity equals the shipped quantity. Events are INCREMENTAL, never
cumulative. Final waves decide the batch:

* wave 0 shipments            -> batch_001 (before the promised time)
* wave 1 shipments (follow-up) -> batch_002 / batch_003 (after the promised time)

Incremental batches are capped at config.incremental_batch_max events. Late
follow-ups always fit (otherwise a ValueError explains how to fix the config).
Open-order follow-ups that do not fit are demoted into batch_001.

Bad events are ADDITIONAL rows (never edits of valid ones) and are recorded in
the test manifest, not in the CSV schema.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta

import pandas as pd

from data_generator import manifest as mf
from data_generator.config import DELIVERY_EVENTS_COLUMNS, GeneratorConfig
from data_generator.generators.orders import LATE, OPEN
from data_generator.utils.counts import rate_count
from data_generator.utils.ids import event_id, shipment_id
from data_generator.utils.random_utils import format_ts, make_rng, parse_ts

# Internal event kinds (never written to CSV)
VALID = "valid"
EARLY = "early_delivery"
NEGATIVE = "negative_delivery"
UNKNOWN_SHIPMENT = "unknown_shipment"
MISSING_ORDER = "missing_order_id"
MISSING_LINE = "missing_line_id"
DUPLICATE = "duplicate"

UNKNOWN_SHIPMENT_START = 900000  # unknown shipment IDs are SHP-900001 and up
HOUR = 3600

_KIND_MANIFEST = {
    EARLY: (mf.DELIVERY_BEFORE_ORDER, mf.FLAG),
    NEGATIVE: (mf.NEGATIVE_DELIVERY, mf.REJECT),
    UNKNOWN_SHIPMENT: (mf.UNKNOWN_SHIPMENT_LINE, mf.QUARANTINE),
    MISSING_ORDER: (mf.MISSING_ORDER_ID, mf.REJECT),
    MISSING_LINE: (mf.MISSING_LINE_ID, mf.REJECT),
    DUPLICATE: (mf.DUPLICATE_EVENT_ID, mf.DEDUPLICATE),
}


def batch_name(index: int) -> str:
    """Zero-based batch index -> 'batch_001', 'batch_002', ..."""
    return f"batch_{index + 1:03d}"


@dataclass
class _Event:
    """Internal event record. kind and source never reach the CSV."""

    shipment_id: str
    order_id: str
    line_id: str
    quantity: int
    time: datetime
    batch: int
    kind: str
    source: "_Event | None" = None
    event_id: str = ""


@dataclass
class DeliveryEventsResult:
    """Delivery event frames keyed by batch name, plus test manifest entries."""

    batches: dict[str, pd.DataFrame]
    manifest: list[dict[str, str]]


def _order_timing(orders: pd.DataFrame) -> dict[str, tuple[datetime, datetime]]:
    """order_id -> (order_time, promised_delivery_time) for well-formed orders."""
    ok = orders[orders["order_id"] != ""]
    return {
        str(o): (parse_ts(ot), parse_ts(pt))
        for o, ot, pt in zip(ok["order_id"], ok["order_time"], ok["promised_delivery_time"])
    }


def _assign_followups(rng: random.Random, plan: pd.DataFrame, n_inc: int, cap: int) -> dict[str, int]:
    """Map order_id -> incremental batch index (1..n_inc) for wave-1 events.

    Late orders are placed first and must fit. Open-order follow-ups are placed
    while there is capacity; the rest are demoted (absent from the result).
    """
    if n_inc == 0:
        return {}
    wave1 = plan[plan["wave"] == 1]
    sizes = wave1.groupby("order_id").size()
    scenario = wave1.groupby("order_id")["scenario"].first()
    late_orders = sorted(str(o) for o in sizes.index if scenario[o] == LATE)
    open_orders = sorted(str(o) for o in sizes.index if scenario[o] == OPEN)
    rng.shuffle(late_orders)
    rng.shuffle(open_orders)

    loads = [0] * (n_inc + 1)  # index 0 unused
    assignment: dict[str, int] = {}

    def least_loaded() -> int:
        return min(range(1, n_inc + 1), key=lambda b: (loads[b], b))

    for oid in late_orders:
        size = int(sizes[oid])
        b = least_loaded()
        if loads[b] + size > cap:
            raise ValueError(
                "Too many late follow-up events for the incremental batch limit. "
                "Reduce --orders, raise --incremental-batch-max, or raise --batches."
            )
        loads[b] += size
        assignment[oid] = b
    for oid in open_orders:
        size = int(sizes[oid])
        b = least_loaded()
        if loads[b] + size <= cap:
            loads[b] += size
            assignment[oid] = b
    return assignment


def _shipment_times(rng: random.Random, plan: pd.DataFrame,
                    timing: dict[str, tuple[datetime, datetime]],
                    post_promise: set[str]) -> dict[str, datetime]:
    """One delivery time per shipment.

    Wave-1 shipments of orders in post_promise arrive 6-48 hours AFTER the
    promised time. Everything else arrives before it (at least 1 hour early).
    """
    times: dict[str, datetime] = {}
    shipments = plan.drop_duplicates("shipment_id")[["shipment_id", "order_id", "wave"]]
    for sid, oid, wave in zip(shipments["shipment_id"], shipments["order_id"], shipments["wave"]):
        order_time, promised = timing[str(oid)]
        if int(wave) == 1 and oid in post_promise:
            times[str(sid)] = promised + timedelta(seconds=rng.randint(6 * HOUR, 48 * HOUR))
        else:
            lead = int((promised - order_time).total_seconds())
            times[str(sid)] = order_time + timedelta(seconds=rng.randint(6 * HOUR, lead - HOUR))
    return times


def _valid_events(plan: pd.DataFrame, followups: dict[str, int], times: dict[str, datetime]) -> list[_Event]:
    """One valid event per shipment line."""
    events = []
    for r in plan.itertuples(index=False):
        batch = followups.get(r.order_id, 0) if int(r.wave) == 1 else 0
        events.append(
            _Event(r.shipment_id, r.order_id, r.line_id, int(r.shipped_quantity), times[r.shipment_id], batch, VALID)
        )
    return events


def _make_specials(rng: random.Random, config: GeneratorConfig, base: list,
                   timing: dict[str, tuple[datetime, datetime]], n_valid: int) -> list[_Event]:
    """Extra bad events built on top of existing on-time shipment lines."""
    if not base:
        return []
    out: list[_Event] = []

    def valid_time(order_time: datetime) -> datetime:
        return order_time + timedelta(seconds=rng.randint(6 * HOUR, 40 * HOUR))

    for _ in range(rate_count(n_valid, config.early_delivery_pct)):
        r = rng.choice(base)
        order_time = timing[r.order_id][0]
        t = order_time - timedelta(seconds=rng.randint(HOUR, 72 * HOUR))  # before order creation
        out.append(_Event(r.shipment_id, r.order_id, r.line_id, rng.randint(1, 5), t, 0, EARLY))

    for _ in range(rate_count(n_valid, config.negative_delivery_pct)):
        r = rng.choice(base)
        t = valid_time(timing[r.order_id][0])
        out.append(_Event(r.shipment_id, r.order_id, r.line_id, -rng.randint(1, 20), t, 0, NEGATIVE))

    for k in range(rate_count(n_valid, config.unknown_shipment_pct)):
        r = rng.choice(base)
        t = valid_time(timing[r.order_id][0])
        if k % 2 == 0:  # shipment_id does not exist at all
            sid, lid = shipment_id(UNKNOWN_SHIPMENT_START + k + 1), r.line_id
        else:  # real shipment, but it has no line L09
            sid, lid = r.shipment_id, "L09"
        out.append(_Event(sid, r.order_id, lid, rng.randint(1, 50), t, 0, UNKNOWN_SHIPMENT))

    for k in range(rate_count(n_valid, config.missing_id_pct)):
        r = rng.choice(base)
        t = valid_time(timing[r.order_id][0])
        if k % 2 == 0:
            out.append(_Event(r.shipment_id, "", r.line_id, int(r.shipped_quantity), t, 0, MISSING_ORDER))
        else:
            out.append(_Event(r.shipment_id, r.order_id, "", int(r.shipped_quantity), t, 0, MISSING_LINE))
    return out


def _clone(src: _Event, batch: int = 0) -> _Event:
    """An exact replay of an existing event (same event_id once IDs are assigned)."""
    return _Event(src.shipment_id, src.order_id, src.line_id, src.quantity, src.time, batch, DUPLICATE, source=src)


def _make_duplicates(rng: random.Random, config: GeneratorConfig, valid: list[_Event]) -> list[_Event]:
    """Duplicates only copy batch_001 events, so the original always arrives first."""
    sources = [e for e in valid if e.batch == 0]
    n = min(len(sources), rate_count(len(valid), config.duplicate_event_pct))
    return [_clone(e) for e in rng.sample(sources, n)]


def _place_specials(rng: random.Random, config: GeneratorConfig, valid: list[_Event],
                    pool: list[_Event]) -> list[_Event]:
    """Fill each incremental batch up to a random target size using bad events.

    Leftover bad events stay in batch_001. If the pool runs out before the
    batch reaches its minimum size, replayed duplicates pad it. Returns padding.
    """
    pool = list(pool)
    rng.shuffle(pool)
    padding: list[_Event] = []
    base = [e for e in valid if e.batch == 0]
    for b in range(1, config.batches):
        current = sum(1 for e in valid if e.batch == b)
        target = rng.randint(max(current, config.incremental_batch_min), config.incremental_batch_max)
        need = target - current
        take = pool[:need]
        del pool[:need]
        for e in take:
            e.batch = b
        shortfall = need - len(take)
        if shortfall > 0 and not base:
            raise ValueError("Not enough events to fill an incremental batch; increase --orders.")
        for _ in range(shortfall):
            padding.append(_clone(rng.choice(base), batch=b))
    return padding


def _assign_event_ids(events: list[_Event]) -> None:
    """Number non-duplicate events in (batch, time) order; duplicates copy their original's ID."""
    originals = [e for e in events if e.source is None]
    originals.sort(key=lambda e: (e.batch, e.time, e.shipment_id, e.order_id, e.line_id, e.kind))
    for n, e in enumerate(originals, start=1):
        e.event_id = event_id(n)
    for e in events:
        if e.source is not None:
            e.event_id = e.source.event_id


def _to_frame(events: list[_Event]) -> pd.DataFrame:
    ordered = sorted(events, key=lambda e: (e.time, e.event_id, e.source is not None))
    rows = [
        {
            "event_id": e.event_id,
            "shipment_id": e.shipment_id,
            "order_id": e.order_id,
            "line_id": e.line_id,
            "delivered_quantity": e.quantity,
            "delivery_time": format_ts(e.time),
        }
        for e in ordered
    ]
    return pd.DataFrame(rows, columns=DELIVERY_EVENTS_COLUMNS)


def _manifest_entries(events: list[_Event], plan: pd.DataFrame) -> list[dict[str, str]]:
    entries = []
    for e in events:
        if e.kind in _KIND_MANIFEST:
            reason, treatment = _KIND_MANIFEST[e.kind]
            entries.append(mf.entry("delivery_events", batch_name(e.batch), e.event_id, reason, treatment))
    over = plan[plan["overdelivery"]]
    for oid, lid in zip(over["order_id"], over["line_id"]):
        entries.append(mf.entry("delivery_events", batch_name(0), f"{oid}|{lid}", mf.OVERDELIVERY, mf.FLAG))
    return entries


def generate_delivery_events(config: GeneratorConfig, orders: pd.DataFrame,
                             plan: pd.DataFrame) -> DeliveryEventsResult:
    """Generate delivery events for every batch."""
    rng = make_rng(config.seed, "delivery_events")
    n_inc = config.batches - 1
    cap = config.incremental_batch_max - max(1, config.incremental_batch_max // 10)

    timing = _order_timing(orders)
    followups = _assign_followups(rng, plan, n_inc, cap)
    if n_inc == 0:  # single batch: follow-ups still arrive late, but in batch_001
        post_promise = set(plan.loc[plan["wave"] == 1, "order_id"])
    else:
        post_promise = set(followups)
    times = _shipment_times(rng, plan, timing, post_promise)
    valid = _valid_events(plan, followups, times)

    base = [r for r in plan.itertuples(index=False) if r.scenario == "on_time" and int(r.wave) == 0]
    specials = _make_specials(rng, config, base, timing, len(valid))
    duplicates = _make_duplicates(rng, config, valid)
    padding = _place_specials(rng, config, valid, specials + duplicates)

    all_events = valid + specials + duplicates + padding
    _assign_event_ids(all_events)

    batches = {
        batch_name(b): _to_frame([e for e in all_events if e.batch == b]) for b in range(config.batches)
    }
    return DeliveryEventsResult(batches, _manifest_entries(all_events, plan))
