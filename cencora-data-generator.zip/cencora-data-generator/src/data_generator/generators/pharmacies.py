"""Pharmacy reference table (includes restricted synthetic contact data)."""
from __future__ import annotations

import pandas as pd

from data_generator.config import PHARMACIES_COLUMNS, REGIONS, GeneratorConfig
from data_generator.utils.ids import pharmacy_id
from data_generator.utils.random_utils import make_rng

FIRST_NAMES = [
    "Alice", "Brian", "Chloe", "Daniel", "Elena", "Farid", "Grace", "Hugo", "Isla", "Jamal",
    "Keiko", "Liam", "Maya", "Noah", "Olivia", "Priya", "Quinn", "Rosa", "Samir", "Tara",
]
LAST_NAMES = [
    "Anderson", "Brooks", "Carter", "Dawson", "Ellis", "Foster", "Grant", "Hughes", "Ibrahim", "Jensen",
    "Kapoor", "Lopez", "Morgan", "Nguyen", "Okafor", "Patel", "Reyes", "Sullivan", "Turner", "Walker",
]
EMAIL_DOMAIN = "example.test"  # reserved test domain: never a real mailbox


def generate_pharmacies(config: GeneratorConfig) -> pd.DataFrame:
    """Generate `config.pharmacies` pharmacies.

    Regions are assigned round-robin so every region is represented.
    contact_name and contact_email are fully synthetic and classified as
    restricted data later in the governance work.
    """
    rng = make_rng(config.seed, "pharmacies")
    rows = []
    for n in range(1, config.pharmacies + 1):
        first = rng.choice(FIRST_NAMES)
        last = rng.choice(LAST_NAMES)
        rows.append(
            {
                "pharmacy_id": pharmacy_id(n),
                "region": REGIONS[(n - 1) % len(REGIONS)],
                "contact_name": f"{first} {last}",
                "contact_email": f"{first}.{last}.{n}@{EMAIL_DOMAIN}".lower(),
            }
        )
    return pd.DataFrame(rows, columns=PHARMACIES_COLUMNS)
