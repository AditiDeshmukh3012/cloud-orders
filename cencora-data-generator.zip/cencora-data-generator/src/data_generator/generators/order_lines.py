"""Order lines: valid lines for every order plus controlled bad line records."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from data_generator.config import ORDER_LINES_COLUMNS, GeneratorConfig
from data_generator.generators.orders import (
    BAD_QUANTITY_ORDER,
    BATCH_1,
    MISSING_LINE_ID_ORDER,
    UNKNOWN_PHARMACY_ORDER,
)
from data_generator.manifest import (
    MISSING_LINE_ID,
    MISSING_ORDER_ID,
    NONPOSITIVE_QUANTITY,
    REJECT,
    entry,
)
from data_generator.utils.counts import rate_count
from data_generator.utils.ids import line_id, product_id
from data_generator.utils.random_utils import make_rng, weighted_choice

LINE_COUNT_CHOICES = [1, 2, 3, 4, 5, 6]
LINE_COUNT_WEIGHTS = [28, 32, 22, 12, 4, 2]  # most orders have 1-4 lines
PACK_QUANTITIES = [10, 12, 20, 24, 30, 40, 50, 60, 100, 120, 150, 200]  # all >= 10 so they can be split
BAD_QUANTITIES = [0, -1, -5, -10]


@dataclass
class OrderLinesResult:
    """Order lines table plus test manifest entries."""

    order_lines: pd.DataFrame
    manifest: list[dict[str, str]]


def _row(oid: str, lid: str, product: str, quantity: int) -> dict[str, object]:
    return {"order_id": oid, "line_id": lid, "product_id": product, "ordered_quantity": quantity}


def generate_order_lines(config: GeneratorConfig, scenarios: dict[str, str]) -> OrderLinesResult:
    """Generate order lines for every order in the scenario map."""
    rng = make_rng(config.seed, "order_lines")
    rows: list[dict[str, object]] = []
    manifest: list[dict[str, str]] = []

    for oid, scenario in scenarios.items():
        if scenario == BAD_QUANTITY_ORDER:
            product = product_id(rng.randint(1, config.products))
            rows.append(_row(oid, line_id(1), product, rng.choice(BAD_QUANTITIES)))
            manifest.append(entry("order_lines", BATCH_1, f"{oid}|{line_id(1)}", NONPOSITIVE_QUANTITY, REJECT))
        elif scenario == MISSING_LINE_ID_ORDER:
            product = product_id(rng.randint(1, config.products))
            rows.append(_row(oid, "", product, rng.choice(PACK_QUANTITIES)))
            manifest.append(entry("order_lines", BATCH_1, f"{oid}|", MISSING_LINE_ID, REJECT))
        else:
            if scenario == UNKNOWN_PHARMACY_ORDER:
                n_lines = rng.choice([1, 2])
            else:
                n_lines = weighted_choice(rng, LINE_COUNT_CHOICES, LINE_COUNT_WEIGHTS)
            n_lines = min(n_lines, config.products)
            products = rng.sample(range(1, config.products + 1), n_lines)  # no repeated product in an order
            for idx, p in enumerate(products, start=1):
                rows.append(_row(oid, line_id(idx), product_id(p), rng.choice(PACK_QUANTITIES)))

    # Lines whose order_id is missing (line_ids L90, L91, ... keep each key unique)
    for k in range(rate_count(config.orders, config.missing_id_pct)):
        lid = line_id(90 + k)
        product = product_id(rng.randint(1, config.products))
        rows.append(_row("", lid, product, rng.choice(PACK_QUANTITIES)))
        manifest.append(entry("order_lines", BATCH_1, f"|{lid}", MISSING_ORDER_ID, REJECT))

    return OrderLinesResult(pd.DataFrame(rows, columns=ORDER_LINES_COLUMNS), manifest)
