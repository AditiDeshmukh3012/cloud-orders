"""Known-result fixture: a handful of orders with hand-computed expected results.

Everything here is typed in by hand. No code computes the expected values, so
the expected_results table is an independent oracle for the future Gold layer.

Assumed report as-of time: 2026-10-01T00:00:00Z (after every promised time).

Scenarios (all IDs use the FX- prefix):

FX-ORD-000001  partial delivery     100 ordered, 60 delivered on time, 40 never arrive
FX-ORD-000002  late completion      60 on time, 40 one day after the promise
FX-ORD-000003  two lines            L01 (50) on time, L02 (30) one day late
FX-ORD-000004  cancelled            excluded from the OTIF denominator
FX-ORD-000005  replay               one 100-unit event delivered on time, listed TWICE
FX-ORD-000006  overdelivery         100 ordered, 120 delivered on time

Assumption: a cancelled order contributes 0 open units (it is no longer expected to ship).
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from data_generator.config import (
    DELIVERY_EVENTS_COLUMNS,
    EXPECTED_RESULTS_COLUMNS,
    ORDER_LINES_COLUMNS,
    ORDERS_COLUMNS,
    SHIPMENT_LINES_COLUMNS,
)

FIXTURE_AS_OF = "2026-10-01T00:00:00Z"

_ORDERS = [
    ("FX-ORD-000001", "PH-0001", "2026-09-01T08:00:00Z", "2026-09-04T08:00:00Z", "OPEN"),
    ("FX-ORD-000002", "PH-0001", "2026-09-01T09:00:00Z", "2026-09-04T09:00:00Z", "COMPLETED"),
    ("FX-ORD-000003", "PH-0001", "2026-09-02T08:00:00Z", "2026-09-05T08:00:00Z", "COMPLETED"),
    ("FX-ORD-000004", "PH-0001", "2026-09-02T10:00:00Z", "2026-09-05T10:00:00Z", "CANCELLED"),
    ("FX-ORD-000005", "PH-0001", "2026-09-03T08:00:00Z", "2026-09-06T08:00:00Z", "COMPLETED"),
    ("FX-ORD-000006", "PH-0001", "2026-09-03T09:00:00Z", "2026-09-06T09:00:00Z", "COMPLETED"),
]

_ORDER_LINES = [
    ("FX-ORD-000001", "L01", "PRD-0001", 100),
    ("FX-ORD-000002", "L01", "PRD-0001", 100),
    ("FX-ORD-000003", "L01", "PRD-0001", 50),
    ("FX-ORD-000003", "L02", "PRD-0002", 30),
    ("FX-ORD-000004", "L01", "PRD-0003", 40),
    ("FX-ORD-000005", "L01", "PRD-0001", 100),
    ("FX-ORD-000006", "L01", "PRD-0002", 100),
]

_SHIPMENT_LINES = [
    ("FX-SHP-000001", "FX-ORD-000001", "L01", 60),
    ("FX-SHP-000002", "FX-ORD-000002", "L01", 60),
    ("FX-SHP-000003", "FX-ORD-000002", "L01", 40),
    ("FX-SHP-000004", "FX-ORD-000003", "L01", 50),
    ("FX-SHP-000005", "FX-ORD-000003", "L02", 30),
    ("FX-SHP-000006", "FX-ORD-000005", "L01", 100),
    ("FX-SHP-000007", "FX-ORD-000006", "L01", 120),
]

# FX-EVT-0000006 appears twice on purpose (replay / duplicate delivery).
_DELIVERY_EVENTS = [
    ("FX-EVT-0000001", "FX-SHP-000001", "FX-ORD-000001", "L01", 60, "2026-09-03T10:00:00Z"),
    ("FX-EVT-0000002", "FX-SHP-000002", "FX-ORD-000002", "L01", 60, "2026-09-03T12:00:00Z"),
    ("FX-EVT-0000003", "FX-SHP-000003", "FX-ORD-000002", "L01", 40, "2026-09-05T09:00:00Z"),
    ("FX-EVT-0000004", "FX-SHP-000004", "FX-ORD-000003", "L01", 50, "2026-09-04T08:00:00Z"),
    ("FX-EVT-0000005", "FX-SHP-000005", "FX-ORD-000003", "L02", 30, "2026-09-06T08:00:00Z"),
    ("FX-EVT-0000006", "FX-SHP-000006", "FX-ORD-000005", "L01", 100, "2026-09-05T08:00:00Z"),
    ("FX-EVT-0000006", "FX-SHP-000006", "FX-ORD-000005", "L01", 100, "2026-09-05T08:00:00Z"),
    ("FX-EVT-0000007", "FX-SHP-000007", "FX-ORD-000006", "L01", 120, "2026-09-05T09:00:00Z"),
]

# order_id, fulfilment %, OTIF, open units, overdelivery flag  (hand-computed)
_EXPECTED = [
    ("FX-ORD-000001", 60.0, "FAIL", 40, "false"),
    ("FX-ORD-000002", 100.0, "FAIL", 0, "false"),
    ("FX-ORD-000003", 100.0, "FAIL", 0, "false"),
    ("FX-ORD-000004", 0.0, "EXCLUDED", 0, "false"),
    ("FX-ORD-000005", 100.0, "PASS", 0, "false"),
    ("FX-ORD-000006", 100.0, "PASS", 0, "true"),
]


@dataclass
class FixtureData:
    """The five fixture tables."""

    orders: pd.DataFrame
    order_lines: pd.DataFrame
    shipment_lines: pd.DataFrame
    delivery_events: pd.DataFrame
    expected_results: pd.DataFrame


def generate_fixture() -> FixtureData:
    """Return the fixed fixture. It takes no seed because nothing is random."""
    return FixtureData(
        orders=pd.DataFrame(_ORDERS, columns=ORDERS_COLUMNS),
        order_lines=pd.DataFrame(_ORDER_LINES, columns=ORDER_LINES_COLUMNS),
        shipment_lines=pd.DataFrame(_SHIPMENT_LINES, columns=SHIPMENT_LINES_COLUMNS),
        delivery_events=pd.DataFrame(_DELIVERY_EVENTS, columns=DELIVERY_EVENTS_COLUMNS),
        expected_results=pd.DataFrame(_EXPECTED, columns=EXPECTED_RESULTS_COLUMNS),
    )
