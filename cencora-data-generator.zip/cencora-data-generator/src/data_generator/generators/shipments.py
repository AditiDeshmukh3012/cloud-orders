"""Shipment lines, built from a per-line shipment plan.

The plan is the link between shipments and delivery events. Wave 0 shipments
belong to the initial load (batch_001); wave 1 shipments are follow-ups that
arrive in later batches. Cancelled orders and invalid-record orders get no
shipments.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

import pandas as pd

from data_generator.config import SHIPMENT_LINES_COLUMNS, GeneratorConfig
from data_generator.generators.orders import LATE, ON_TIME, OPEN
from data_generator.utils.counts import rate_count, split_quantity
from data_generator.utils.ids import shipment_id
from data_generator.utils.random_utils import make_rng

PLAN_COLUMNS = SHIPMENT_LINES_COLUMNS + ["scenario", "wave", "ordered_quantity", "overdelivery"]
MULTI_SHIPMENT_PROB = 0.25  # share of on-time orders split into two shipments
LATE_EXTRA_LINE_PROB = 0.4  # chance each extra line of a late order is also late
OPEN_LINE_SHIPPED_PROB = 0.7
OPEN_FOLLOW_UP_PROB = 0.4


@dataclass
class ShipmentsResult:
    """shipment_lines is the output table; plan carries internal planning columns."""

    shipment_lines: pd.DataFrame
    plan: pd.DataFrame


class _ShipmentCounter:
    def __init__(self) -> None:
        self.n = 0

    def next(self) -> str:
        self.n += 1
        return shipment_id(self.n)


def _row(sid: str, oid: str, lid: str, shipped: int, scenario: str, wave: int, ordered: int,
         over: bool = False) -> dict[str, object]:
    return {
        "shipment_id": sid,
        "order_id": oid,
        "line_id": lid,
        "shipped_quantity": shipped,
        "scenario": scenario,
        "wave": wave,
        "ordered_quantity": ordered,
        "overdelivery": over,
    }


def _valid_lines_by_order(order_lines: pd.DataFrame) -> dict[str, list[tuple[str, int]]]:
    """Only well-formed lines can be shipped."""
    ok = order_lines[
        (order_lines["order_id"] != "") & (order_lines["line_id"] != "") & (order_lines["ordered_quantity"] > 0)
    ]
    result: dict[str, list[tuple[str, int]]] = {}
    for oid, group in ok.groupby("order_id", sort=True):
        result[str(oid)] = [(str(lid), int(q)) for lid, q in zip(group["line_id"], group["ordered_quantity"])]
    return result


def _pick_overdelivery_orders(rng: random.Random, config: GeneratorConfig, scenarios: dict[str, str]) -> set[str]:
    on_time_ids = sorted(o for o, s in scenarios.items() if s == ON_TIME)
    n = min(len(on_time_ids), rate_count(config.orders, config.overdelivery_pct))
    return set(rng.sample(on_time_ids, n))


def _plan_on_time(rng: random.Random, counter: _ShipmentCounter, oid: str,
                  lines: list[tuple[str, int]], over_line: str | None) -> list[dict[str, object]]:
    """All lines fully shipped in wave 0, optionally split over two shipments."""
    rows = []
    split = rng.random() < MULTI_SHIPMENT_PROB
    s1 = counter.next()
    s2 = counter.next() if split else None
    for lid, qty in lines:
        extra = max(1, qty // 5) if lid == over_line else 0  # +20%: raw overdelivery
        if split:
            first = split_quantity(rng, qty)
            rows.append(_row(s1, oid, lid, first, ON_TIME, 0, qty))
            rows.append(_row(s2, oid, lid, qty - first + extra, ON_TIME, 0, qty, extra > 0))
        else:
            rows.append(_row(s1, oid, lid, qty + extra, ON_TIME, 0, qty, extra > 0))
    return rows


def _plan_late(rng: random.Random, counter: _ShipmentCounter, oid: str,
               lines: list[tuple[str, int]]) -> list[dict[str, object]]:
    """At least one line is shipped in two waves; its remainder arrives after the promise."""
    rows = []
    late_idx = rng.randrange(len(lines))  # guarantees the order is late
    s0 = counter.next()
    s1 = counter.next()
    for i, (lid, qty) in enumerate(lines):
        if i == late_idx or rng.random() < LATE_EXTRA_LINE_PROB:
            first = split_quantity(rng, qty, 0.4, 0.8)
            rows.append(_row(s0, oid, lid, first, LATE, 0, qty))
            rows.append(_row(s1, oid, lid, qty - first, LATE, 1, qty))
        else:
            rows.append(_row(s0, oid, lid, qty, LATE, 0, qty))
    return rows


def _plan_open(rng: random.Random, counter: _ShipmentCounter, oid: str,
               lines: list[tuple[str, int]]) -> list[dict[str, object]]:
    """Partial shipments only: the order can never complete, so open units remain."""
    rows = []
    chosen = [rng.random() < OPEN_LINE_SHIPPED_PROB for _ in lines]
    if not any(chosen):
        chosen[rng.randrange(len(lines))] = True  # at least one line ships something
    s0 = counter.next()
    remaining: list[tuple[str, int, int]] = []
    for (lid, qty), ship in zip(lines, chosen):
        part = split_quantity(rng, qty, 0.3, 0.8) if ship else 0
        if part:
            rows.append(_row(s0, oid, lid, part, OPEN, 0, qty))
        remaining.append((lid, qty, qty - part))

    if rng.random() < OPEN_FOLLOW_UP_PROB:
        follow_up = []
        for lid, qty, rest in remaining:
            if rest >= 2:
                follow_up.append((lid, qty, rng.randint(1, rest // 2)))  # never completes the line
        if follow_up:
            s1 = counter.next()
            for lid, qty, shipped in follow_up:
                rows.append(_row(s1, oid, lid, shipped, OPEN, 1, qty))
    return rows


def generate_shipments(config: GeneratorConfig, order_lines: pd.DataFrame,
                       scenarios: dict[str, str]) -> ShipmentsResult:
    """Generate shipment lines for on_time, late and open orders."""
    rng = make_rng(config.seed, "shipments")
    counter = _ShipmentCounter()
    lines_by_order = _valid_lines_by_order(order_lines)
    over_orders = _pick_overdelivery_orders(rng, config, scenarios)

    rows: list[dict[str, object]] = []
    for oid in sorted(lines_by_order):
        scenario = scenarios.get(oid)
        lines = lines_by_order[oid]
        if scenario == ON_TIME:
            over_line = rng.choice(lines)[0] if oid in over_orders else None
            rows.extend(_plan_on_time(rng, counter, oid, lines, over_line))
        elif scenario == LATE:
            rows.extend(_plan_late(rng, counter, oid, lines))
        elif scenario == OPEN:
            rows.extend(_plan_open(rng, counter, oid, lines))

    plan = pd.DataFrame(rows, columns=PLAN_COLUMNS)
    plan = plan.sort_values(["shipment_id", "line_id"]).reset_index(drop=True)
    return ShipmentsResult(plan[SHIPMENT_LINES_COLUMNS].copy(), plan)
