"""Configuration and schema definitions for the data generator."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_SEED = 42

# Required source schemas (column order = CSV column order).
# No test-explanation columns are ever added to these.
ORDERS_COLUMNS = ["order_id", "pharmacy_id", "order_time", "promised_delivery_time", "order_status"]
ORDER_LINES_COLUMNS = ["order_id", "line_id", "product_id", "ordered_quantity"]
SHIPMENT_LINES_COLUMNS = ["shipment_id", "order_id", "line_id", "shipped_quantity"]
DELIVERY_EVENTS_COLUMNS = ["event_id", "shipment_id", "order_id", "line_id", "delivered_quantity", "delivery_time"]
PHARMACIES_COLUMNS = ["pharmacy_id", "region", "contact_name", "contact_email"]
EXPECTED_RESULTS_COLUMNS = [
    "order_id",
    "expected_fulfilment_percent",
    "expected_otif",
    "expected_open_units",
    "expected_overdelivery_flag",
]

SCHEMAS: dict[str, list[str]] = {
    "orders": ORDERS_COLUMNS,
    "order_lines": ORDER_LINES_COLUMNS,
    "shipment_lines": SHIPMENT_LINES_COLUMNS,
    "delivery_events": DELIVERY_EVENTS_COLUMNS,
    "pharmacies": PHARMACIES_COLUMNS,
}

REGIONS = ["North", "South", "East", "West", "Central"]
ORDER_STATUSES = ["OPEN", "CANCELLED", "COMPLETED"]


@dataclass(frozen=True)
class GeneratorConfig:
    """All tunable settings. Same config + same seed => identical output."""

    seed: int = DEFAULT_SEED
    pharmacies: int = 100
    products: int = 200
    orders: int = 2000
    start_date: str = "2026-08-01"   # earliest order_time (UTC)
    end_date: str = "2026-09-20"     # latest order_time (UTC)
    batches: int = 3                 # batch_001 = baseline load, rest = incremental
    incremental_batch_min: int = 100  # min delivery events in batch_002+
    incremental_batch_max: int = 500  # max delivery events in batch_002+
    output_dir: str = "output"

    # Order outcome mix (must sum to 1.0)
    on_time_pct: float = 0.50
    late_pct: float = 0.20
    open_pct: float = 0.25
    cancelled_pct: float = 0.05

    # Controlled bad-record rates (fraction of the relevant rows)
    overdelivery_pct: float = 0.02
    early_delivery_pct: float = 0.01
    duplicate_event_pct: float = 0.02
    unknown_pharmacy_pct: float = 0.01
    missing_id_pct: float = 0.01
    nonpositive_quantity_pct: float = 0.01
    negative_delivery_pct: float = 0.01
    unknown_shipment_pct: float = 0.01

    def __post_init__(self) -> None:
        if self.pharmacies < 1 or self.products < 1 or self.orders < 1:
            raise ValueError("pharmacies, products and orders must be >= 1")
        if self.batches < 1:
            raise ValueError("batches must be >= 1")
        if not 0 < self.incremental_batch_min <= self.incremental_batch_max:
            raise ValueError("need 0 < incremental_batch_min <= incremental_batch_max")
        if self.start_dt >= self.end_dt:
            raise ValueError("start_date must be earlier than end_date")
        mix = self.on_time_pct + self.late_pct + self.open_pct + self.cancelled_pct
        if abs(mix - 1.0) > 1e-9:
            raise ValueError(f"order outcome mix must sum to 1.0, got {mix}")
        for name, value in self.invalid_rates().items():
            if not 0.0 <= value <= 0.2:
                raise ValueError(f"{name} must be between 0 and 0.2 (bad records must stay a minority)")

    @property
    def start_dt(self) -> datetime:
        return datetime.strptime(self.start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)

    @property
    def end_dt(self) -> datetime:
        return datetime.strptime(self.end_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)

    @property
    def output_path(self) -> Path:
        return Path(self.output_dir)

    def invalid_rates(self) -> dict[str, float]:
        """All controlled bad-record percentages in one place."""
        return {
            "overdelivery_pct": self.overdelivery_pct,
            "early_delivery_pct": self.early_delivery_pct,
            "duplicate_event_pct": self.duplicate_event_pct,
            "unknown_pharmacy_pct": self.unknown_pharmacy_pct,
            "missing_id_pct": self.missing_id_pct,
            "nonpositive_quantity_pct": self.nonpositive_quantity_pct,
            "negative_delivery_pct": self.negative_delivery_pct,
            "unknown_shipment_pct": self.unknown_shipment_pct,
        }

    def to_dict(self) -> dict:
        return asdict(self)
