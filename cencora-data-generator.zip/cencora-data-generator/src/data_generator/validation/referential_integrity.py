"""Self-validation of the generated dataset.

The generator deliberately creates bad records. Validation therefore uses the
test manifest as an answer key:

* a bad-looking record that IS in the manifest must really show its defect;
* a bad-looking record that is NOT in the manifest is a generator bug.

Errors fail the run. Warnings (e.g. a bad-record type disabled by setting its
rate to 0) are logged but do not fail it.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd
from pandas.api.types import is_integer_dtype

from data_generator import manifest as mf
from data_generator.config import ORDER_STATUSES, SCHEMAS, EXPECTED_RESULTS_COLUMNS
from data_generator.dataset import GeneratedDataset
from data_generator.generators.fixtures import FixtureData

TIMESTAMP_PATTERN = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z"
EVENT_COLUMNS = SCHEMAS["delivery_events"]
EVENT_KEY = ["shipment_id", "order_id", "line_id"]


class GeneratorValidationError(Exception):
    """Raised when the generated data contains an unexpected defect."""


@dataclass
class ValidationReport:
    """Collects errors and warnings from all checks."""

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checks_run: int = 0

    def check(self, condition: bool, message: str) -> bool:
        """Record an error when `condition` is false."""
        self.checks_run += 1
        if not bool(condition):
            self.errors.append(message)
            return False
        return True

    def warn_unless(self, condition: bool, message: str) -> None:
        """Record a warning when `condition` is false."""
        self.checks_run += 1
        if not bool(condition):
            self.warnings.append(message)

    @property
    def ok(self) -> bool:
        return not self.errors

    def raise_if_failed(self) -> None:
        if self.errors:
            shown = "\n  - ".join(self.errors[:20])
            extra = f"\n  ... and {len(self.errors) - 20} more" if len(self.errors) > 20 else ""
            raise GeneratorValidationError(f"{len(self.errors)} validation error(s):\n  - {shown}{extra}")


# ----------------------------------------------------------------- helpers
def _bad_timestamps(series: pd.Series) -> int:
    return int((~series.astype(str).str.fullmatch(TIMESTAMP_PATTERN)).sum())


def _manifest_rows(manifest: pd.DataFrame, dataset: str, reason: str) -> pd.DataFrame:
    return manifest[(manifest["dataset"] == dataset) & (manifest["reason"] == reason)]


def _all_events(ds: GeneratedDataset) -> pd.DataFrame:
    parts = [df.assign(batch=name) for name, df in ds.delivery_batches.items()]
    return pd.concat(parts, ignore_index=True)


# ----------------------------------------------------------------- schemas
def _check_schemas(r: ValidationReport, ds: GeneratedDataset) -> None:
    named = {
        "pharmacies": ds.pharmacies,
        "orders": ds.orders,
        "order_lines": ds.order_lines,
        "shipment_lines": ds.shipment_lines,
    }
    for name, df in named.items():
        r.check(list(df.columns) == SCHEMAS[name], f"{name}: columns must be exactly {SCHEMAS[name]}")
    for batch, df in ds.delivery_batches.items():
        r.check(list(df.columns) == EVENT_COLUMNS, f"{batch}/delivery_events: columns must be exactly {EVENT_COLUMNS}")
    if not r.ok:
        return
    r.check(is_integer_dtype(ds.order_lines["ordered_quantity"]), "order_lines.ordered_quantity must be integer")
    r.check(is_integer_dtype(ds.shipment_lines["shipped_quantity"]), "shipment_lines.shipped_quantity must be integer")
    for batch, df in ds.delivery_batches.items():
        r.check(is_integer_dtype(df["delivered_quantity"]), f"{batch}: delivered_quantity must be integer")
        r.check(_bad_timestamps(df["delivery_time"]) == 0, f"{batch}: delivery_time must be ISO-8601 UTC (...Z)")
    for col in ("order_time", "promised_delivery_time"):
        r.check(_bad_timestamps(ds.orders[col]) == 0, f"orders.{col} must be ISO-8601 UTC (...Z)")


# ----------------------------------------------------------------- orders
def _check_orders(r: ValidationReport, ds: GeneratedDataset) -> pd.DataFrame:
    """Returns the well-formed orders (non-empty order_id)."""
    o, m = ds.orders, ds.manifest
    pharmacies = ds.pharmacies
    r.check(pharmacies["pharmacy_id"].is_unique, "pharmacies: pharmacy_id must be unique")
    r.check(bool((pharmacies[["region", "contact_name", "contact_email"]] != "").all().all()),
            "pharmacies: region and contact fields must not be empty")

    missing = o[o["order_id"] == ""]
    r.check(len(missing) == len(_manifest_rows(m, "orders", mf.MISSING_ORDER_ID)),
            "orders: rows with missing order_id must match the manifest exactly")

    ok = o[o["order_id"] != ""]
    r.check(ok["order_id"].is_unique, "orders: order_id must be unique")
    r.check(bool(ok["order_status"].isin(ORDER_STATUSES).all()), f"orders: order_status must be in {ORDER_STATUSES}")
    r.check(bool((ok["promised_delivery_time"] > ok["order_time"]).all()),
            "orders: promised_delivery_time must be after order_time")

    known = set(pharmacies["pharmacy_id"])
    unknown = set(ok.loc[~ok["pharmacy_id"].isin(known), "order_id"])
    expected = set(_manifest_rows(m, "orders", mf.UNKNOWN_PHARMACY)["record_key"])
    r.check(unknown == expected, "orders: unknown-pharmacy orders must match the manifest exactly")
    return ok


# ----------------------------------------------------------------- order lines
def _check_order_lines(r: ValidationReport, ds: GeneratedDataset, orders_ok: pd.DataFrame) -> pd.DataFrame:
    """Returns the valid lines (keys present, quantity > 0)."""
    ol, m = ds.order_lines, ds.manifest

    no_order = ol[ol["order_id"] == ""]
    r.check(len(no_order) == len(_manifest_rows(m, "order_lines", mf.MISSING_ORDER_ID)),
            "order_lines: rows with missing order_id must match the manifest exactly")
    no_line = ol[(ol["order_id"] != "") & (ol["line_id"] == "")]
    r.check(len(no_line) == len(_manifest_rows(m, "order_lines", mf.MISSING_LINE_ID)),
            "order_lines: rows with missing line_id must match the manifest exactly")

    wellformed = ol[(ol["order_id"] != "") & (ol["line_id"] != "")]
    r.check(not wellformed.duplicated(["order_id", "line_id"]).any(), "order_lines: (order_id, line_id) must be unique")

    nonpositive = wellformed[wellformed["ordered_quantity"] <= 0]
    found = set(nonpositive["order_id"] + "|" + nonpositive["line_id"])
    expected = set(_manifest_rows(m, "order_lines", mf.NONPOSITIVE_QUANTITY)["record_key"])
    r.check(found == expected, "order_lines: nonpositive quantities must match the manifest exactly")

    good = wellformed[wellformed["ordered_quantity"] > 0]
    r.check(bool(good["order_id"].isin(set(orders_ok["order_id"])).all()),
            "order_lines: every valid line must reference an existing order")
    r.check(bool(orders_ok["order_id"].isin(set(ol["order_id"])).all()),
            "orders: every order must have at least one order line row")
    return good


# ----------------------------------------------------------------- shipments
def _check_shipment_lines(r: ValidationReport, ds: GeneratedDataset, lines_ok: pd.DataFrame) -> set[tuple[str, str, str]]:
    """Returns the set of (shipment_id, order_id, line_id) keys."""
    sl = ds.shipment_lines
    r.check(not sl.duplicated(EVENT_KEY).any(), "shipment_lines: (shipment_id, order_id, line_id) must be unique")
    r.check(bool((sl["shipped_quantity"] > 0).all()), "shipment_lines: shipped_quantity must be positive")
    line_keys = set(zip(lines_ok["order_id"], lines_ok["line_id"]))
    orphans = sum(k not in line_keys for k in zip(sl["order_id"], sl["line_id"]))
    r.check(orphans == 0, f"shipment_lines: {orphans} row(s) reference a missing order line")
    return set(zip(sl["shipment_id"], sl["order_id"], sl["line_id"]))


# ----------------------------------------------------------------- delivery events
def _check_delivery_events(r: ValidationReport, ds: GeneratedDataset, orders_ok: pd.DataFrame,
                           lines_ok: pd.DataFrame, ship_keys: set[tuple[str, str, str]]) -> None:
    cfg = ds.config
    dm = ds.manifest[ds.manifest["dataset"] == "delivery_events"]
    events = _all_events(ds)
    order_time = dict(zip(orders_ok["order_id"], orders_ok["order_time"]))

    # --- batches
    r.check(len(ds.delivery_batches) == cfg.batches, "number of delivery batches must equal config.batches")
    names = list(ds.delivery_batches)
    for i, name in enumerate(names):
        size = len(ds.delivery_batches[name])
        r.check(size > 0, f"{name}: batch must not be empty")
        if i > 0:
            r.check(cfg.incremental_batch_min <= size <= cfg.incremental_batch_max,
                    f"{name}: {size} events is outside {cfg.incremental_batch_min}-{cfg.incremental_batch_max}")

    # --- identifiers and duplicates
    r.check(bool((events["event_id"] != "").all()), "delivery_events: every event needs an event_id")
    is_dup = events["event_id"].duplicated(keep="first")
    firsts, dups = events[~is_dup], events[is_dup]
    r.check(len(dups) == int((dm["reason"] == mf.DUPLICATE_EVENT_ID).sum()),
            "delivery_events: duplicate event_id rows must match the manifest exactly")
    if len(dups):
        lookup = firsts.set_index("event_id")
        same = all(
            bool((dups[c].to_numpy() == lookup.loc[dups["event_id"], c].to_numpy()).all()) for c in EVENT_COLUMNS[1:]
        )
        r.check(same, "delivery_events: duplicates must be exact copies of an earlier event")

    refs = events.loc[events["order_id"] != "", "order_id"]
    r.check(bool(refs.isin(set(order_time)).all()), "delivery_events: every non-empty order_id must exist in orders")

    # --- intentional bad events must really be bad
    def ids(reason: str) -> set[str]:
        return set(dm.loc[dm["reason"] == reason, "record_key"])

    groups = {
        mf.DELIVERY_BEFORE_ORDER: ids(mf.DELIVERY_BEFORE_ORDER),
        mf.NEGATIVE_DELIVERY: ids(mf.NEGATIVE_DELIVERY),
        mf.UNKNOWN_SHIPMENT_LINE: ids(mf.UNKNOWN_SHIPMENT_LINE),
        mf.MISSING_ORDER_ID: ids(mf.MISSING_ORDER_ID),
        mf.MISSING_LINE_ID: ids(mf.MISSING_LINE_ID),
    }
    bad_ids = set().union(*groups.values())
    bad = firsts[firsts["event_id"].isin(bad_ids)]
    r.check(len(bad) == len(bad_ids), "delivery_events: every manifest bad event must exist exactly once")

    def pick(reason: str) -> pd.DataFrame:
        return firsts[firsts["event_id"].isin(groups[reason])]

    early = pick(mf.DELIVERY_BEFORE_ORDER)
    r.check(bool((early["delivery_time"] < early["order_id"].map(order_time).fillna("")).all()),
            "bad events: early-delivery events must be earlier than order_time")
    r.check(bool((pick(mf.NEGATIVE_DELIVERY)["delivered_quantity"] < 0).all()),
            "bad events: negative-delivery events must have delivered_quantity < 0")
    unk = pick(mf.UNKNOWN_SHIPMENT_LINE)
    r.check(all(k not in ship_keys for k in zip(unk["shipment_id"], unk["order_id"], unk["line_id"])),
            "bad events: unknown-shipment events must not match any shipment line")
    r.check(bool((pick(mf.MISSING_ORDER_ID)["order_id"] == "").all()), "bad events: missing-order_id events need an empty order_id")
    r.check(bool((pick(mf.MISSING_LINE_ID)["line_id"] == "").all()), "bad events: missing-line_id events need an empty line_id")

    # --- everything else must be fully valid (otherwise it is a generator bug)
    valid = firsts[~firsts["event_id"].isin(bad_ids)]
    r.check(bool(((valid["order_id"] != "") & (valid["line_id"] != "")).all()), "valid events: order_id and line_id must be present")
    r.check(bool((valid["delivered_quantity"] > 0).all()), "valid events: delivered_quantity must be positive")
    keys = list(zip(valid["shipment_id"], valid["order_id"], valid["line_id"]))
    r.check(all(k in ship_keys for k in keys), "valid events: must reference an existing shipment line")
    mapped = valid["order_id"].map(order_time)
    r.check(bool(mapped.notna().all()), "valid events: must reference an existing order")
    r.check(bool((valid["delivery_time"] >= mapped.fillna("~")).all()), "valid events: delivery_time must not precede order_time")

    per_shipment = (
        valid.groupby(EVENT_KEY).agg(n=("event_id", "size"), qty=("delivered_quantity", "sum")).reset_index()
    )
    joined = ds.shipment_lines.merge(per_shipment, on=EVENT_KEY, how="left")
    r.check(bool(joined["n"].eq(1).all()), "every shipment line must have exactly one valid delivery event")
    r.check(bool((joined["qty"] == joined["shipped_quantity"]).all()), "valid events: delivered_quantity must equal shipped_quantity")

    # --- overdelivery must match the manifest exactly
    delivered = valid.groupby(["order_id", "line_id"])["delivered_quantity"].sum().to_frame("delivered")
    ordered = lines_ok.set_index(["order_id", "line_id"])[["ordered_quantity"]]
    both = delivered.join(ordered, how="left")
    over = {f"{o}|{l}" for (o, l) in both.index[both["delivered"] > both["ordered_quantity"]]}
    r.check(over == set(_manifest_rows(ds.manifest, "delivery_events", mf.OVERDELIVERY)["record_key"]),
            "overdelivered lines must match the manifest exactly")

    # --- incremental batches should touch orders that already exist (warning only)
    valid_b = valid.assign(batch=valid["event_id"].map(firsts.set_index("event_id")["batch"]))
    base_orders = set(valid_b.loc[valid_b["batch"] == names[0], "order_id"])
    for name in names[1:]:
        touches = valid_b[(valid_b["batch"] == name) & valid_b["order_id"].isin(base_orders)]
        r.warn_unless(len(touches) > 0, f"{name}: has no new valid events for orders already seen in {names[0]}")


# ----------------------------------------------------------------- scenario coverage
def _check_scenario_coverage(r: ValidationReport, ds: GeneratedDataset) -> None:
    present = set(ds.manifest["reason"])
    for reason in (mf.UNKNOWN_PHARMACY, mf.MISSING_ORDER_ID, mf.MISSING_LINE_ID, mf.NONPOSITIVE_QUANTITY,
                   mf.NEGATIVE_DELIVERY, mf.UNKNOWN_SHIPMENT_LINE, mf.DUPLICATE_EVENT_ID,
                   mf.DELIVERY_BEFORE_ORDER, mf.OVERDELIVERY):
        r.warn_unless(reason in present, f"scenario coverage: no '{reason}' records were generated")
    if ds.config.cancelled_pct > 0:
        r.check(bool((ds.orders["order_status"] == "CANCELLED").any()), "scenario coverage: cancelled orders must exist")


# ----------------------------------------------------------------- fixture
def _recompute_fixture(fx: FixtureData) -> dict[str, tuple[float, str, int, str]]:
    """Plain re-derivation used ONLY as a typo guard for the hand-typed table."""
    events = fx.delivery_events.drop_duplicates("event_id")
    out: dict[str, tuple[float, str, int, str]] = {}
    for o in fx.orders.itertuples(index=False):
        if o.order_status == "CANCELLED":
            out[o.order_id] = (0.0, "EXCLUDED", 0, "false")
            continue
        ordered_total = capped_total = open_units = 0
        otif, over = True, False
        for l in fx.order_lines[fx.order_lines["order_id"] == o.order_id].itertuples(index=False):
            ev = events[(events["order_id"] == o.order_id) & (events["line_id"] == l.line_id)]
            delivered = int(ev["delivered_quantity"].sum())
            on_time = int(ev.loc[ev["delivery_time"] <= o.promised_delivery_time, "delivered_quantity"].sum())
            ordered_total += l.ordered_quantity
            capped_total += min(delivered, l.ordered_quantity)
            open_units += max(0, l.ordered_quantity - delivered)
            otif = otif and on_time >= l.ordered_quantity
            over = over or delivered > l.ordered_quantity
        out[o.order_id] = (round(100 * capped_total / ordered_total, 2), "PASS" if otif else "FAIL",
                           open_units, "true" if over else "false")
    return out


def _check_fixture(r: ValidationReport, fx: FixtureData) -> None:
    tables = {
        "orders": fx.orders, "order_lines": fx.order_lines, "shipment_lines": fx.shipment_lines,
        "delivery_events": fx.delivery_events,
    }
    for name, df in tables.items():
        r.check(list(df.columns) == SCHEMAS[name], f"fixture/{name}: columns must be exactly {SCHEMAS[name]}")
    r.check(list(fx.expected_results.columns) == EXPECTED_RESULTS_COLUMNS, "fixture/expected_results: wrong columns")
    if not r.ok:
        return

    order_ids = set(fx.orders["order_id"])
    r.check(fx.orders["order_id"].is_unique, "fixture: order_id must be unique")
    r.check(not fx.order_lines.duplicated(["order_id", "line_id"]).any(), "fixture: order line keys must be unique")
    line_keys = set(zip(fx.order_lines["order_id"], fx.order_lines["line_id"]))
    r.check(set(fx.order_lines["order_id"]) <= order_ids, "fixture: order lines must reference fixture orders")
    r.check(set(zip(fx.shipment_lines["order_id"], fx.shipment_lines["line_id"])) <= line_keys,
            "fixture: shipment lines must reference fixture order lines")
    ship_keys = set(zip(fx.shipment_lines["shipment_id"], fx.shipment_lines["order_id"], fx.shipment_lines["line_id"]))
    ev = fx.delivery_events
    r.check(set(zip(ev["shipment_id"], ev["order_id"], ev["line_id"])) <= ship_keys,
            "fixture: delivery events must reference fixture shipment lines")
    r.check(set(fx.expected_results["order_id"]) == order_ids, "fixture: expected_results must cover exactly the fixture orders")
    r.check(int(ev["event_id"].duplicated().sum()) >= 1, "fixture: a replayed (duplicate) event must exist")
    r.check(int(ev.duplicated().sum()) == int(ev["event_id"].duplicated().sum()), "fixture: duplicate events must be exact copies")
    r.check(bool((fx.orders["order_status"] == "CANCELLED").any()), "fixture: a cancelled order must exist")

    recomputed = _recompute_fixture(fx)
    for row in fx.expected_results.itertuples(index=False):
        pct, otif, open_units, flag = recomputed[row.order_id]
        got = (float(row.expected_fulfilment_percent), row.expected_otif, int(row.expected_open_units), row.expected_overdelivery_flag)
        r.check(abs(got[0] - pct) < 0.01 and got[1:] == (otif, open_units, flag),
                f"fixture: expected result for {row.order_id} is {got} but re-derivation gives {(pct, otif, open_units, flag)}")


# ----------------------------------------------------------------- entry point
def validate_dataset(ds: GeneratedDataset) -> ValidationReport:
    """Run every check and return the report (does not raise)."""
    report = ValidationReport()
    _check_schemas(report, ds)
    if not report.ok:
        return report
    orders_ok = _check_orders(report, ds)
    lines_ok = _check_order_lines(report, ds, orders_ok)
    ship_keys = _check_shipment_lines(report, ds, lines_ok)
    _check_delivery_events(report, ds, orders_ok, lines_ok, ship_keys)
    _check_scenario_coverage(report, ds)
    _check_fixture(report, ds.fixture)
    return report
