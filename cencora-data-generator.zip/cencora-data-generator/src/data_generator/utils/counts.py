"""Small deterministic helpers for counts and quantity splitting."""
from __future__ import annotations

import random


def rate_count(total: int, rate: float) -> int:
    """Number of records for a percentage rate; at least 1 when the rate is > 0."""
    if rate <= 0 or total <= 0:
        return 0
    return max(1, int(round(total * rate)))


def allocate_counts(total: int, fractions: dict[str, float]) -> dict[str, int]:
    """Split `total` across keys using the largest-remainder method.

    Counts always sum exactly to `total`. When there is room, every key with a
    positive fraction gets at least one item so every scenario exists.
    """
    keys = list(fractions)
    raw = {k: total * fractions[k] for k in keys}
    counts = {k: int(raw[k]) for k in keys}
    leftover = total - sum(counts.values())
    by_remainder = sorted(keys, key=lambda k: (-(raw[k] - counts[k]), keys.index(k)))
    for k in by_remainder[:leftover]:
        counts[k] += 1
    if total >= len(keys):
        for k in keys:
            if fractions[k] > 0 and counts[k] == 0:
                donor = max(keys, key=lambda x: counts[x])
                counts[donor] -= 1
                counts[k] += 1
    return counts


def split_quantity(rng: random.Random, quantity: int, low: float = 0.4, high: float = 0.7) -> int:
    """Return a first part strictly between 1 and quantity-1 (both parts >= 1)."""
    if quantity < 2:
        raise ValueError("quantity must be at least 2 to split")
    part = int(round(quantity * rng.uniform(low, high)))
    return min(max(part, 1), quantity - 1)
