"""Deterministic random helpers.

Every generator gets its own random.Random instance derived from the single
user-facing seed plus a namespace string. This keeps each generator
reproducible AND independent: changing how many random numbers one generator
consumes does not shift the numbers seen by another.

hashlib is used (not the built-in hash()) because hash() of strings is
randomised per Python process and would break reproducibility.
"""
from __future__ import annotations

import hashlib
import random
from datetime import datetime, timedelta, timezone
from typing import Sequence, TypeVar

T = TypeVar("T")

TS_FORMAT = "%Y-%m-%dT%H:%M:%SZ"


def derive_seed(base_seed: int, namespace: str) -> int:
    """Derive a stable 64-bit seed from a base seed and a namespace."""
    digest = hashlib.sha256(f"{base_seed}:{namespace}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def make_rng(base_seed: int, namespace: str) -> random.Random:
    """Create an independent, deterministic RNG for the given namespace."""
    return random.Random(derive_seed(base_seed, namespace))


def weighted_choice(rng: random.Random, items: Sequence[T], weights: Sequence[float]) -> T:
    """Pick one item using relative weights."""
    return rng.choices(list(items), weights=list(weights), k=1)[0]


def random_datetime(rng: random.Random, start: datetime, end: datetime) -> datetime:
    """Return a random UTC datetime in [start, end], truncated to whole seconds."""
    if end < start:
        raise ValueError("end must not be earlier than start")
    span_seconds = int((end - start).total_seconds())
    return start.replace(microsecond=0) + timedelta(seconds=rng.randint(0, span_seconds))


def format_ts(value: datetime) -> str:
    """Format a datetime as ISO-8601 UTC, e.g. 2026-10-01T10:30:00Z."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).strftime(TS_FORMAT)


def parse_ts(value: str) -> datetime:
    """Parse a timestamp produced by format_ts back into an aware datetime."""
    return datetime.strptime(value, TS_FORMAT).replace(tzinfo=timezone.utc)
