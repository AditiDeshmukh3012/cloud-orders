"""Deterministic ID builders. All IDs are strings.

An optional prefix lets the known-result fixture use its own ID space
(e.g. "FX-") so fixture IDs can never collide with main-dataset IDs.
"""
from __future__ import annotations


def pharmacy_id(n: int) -> str:
    return f"PH-{n:04d}"


def product_id(n: int) -> str:
    return f"PRD-{n:04d}"


def order_id(n: int, prefix: str = "") -> str:
    return f"{prefix}ORD-{n:06d}"


def line_id(n: int) -> str:
    """Line IDs are only unique within an order: L01, L02, ..."""
    return f"L{n:02d}"


def shipment_id(n: int, prefix: str = "") -> str:
    return f"{prefix}SHP-{n:06d}"


def event_id(n: int, prefix: str = "") -> str:
    return f"{prefix}EVT-{n:07d}"
