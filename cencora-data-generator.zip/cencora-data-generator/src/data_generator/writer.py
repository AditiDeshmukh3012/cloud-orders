"""CSV output: file layout, cleanup of old output, checksums and run summary."""
from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
from pathlib import Path

import pandas as pd

from data_generator.dataset import GeneratedDataset

logger = logging.getLogger(__name__)

GENERATED_DIRS = {"reference", "fixture", "metadata"}
BATCH_DIR = re.compile(r"batch_\d{3}")
INT_COLUMNS = {"ordered_quantity", "shipped_quantity", "delivered_quantity", "expected_open_units"}
FLOAT_COLUMNS = {"expected_fulfilment_percent"}


def read_csv_strict(path: Path) -> pd.DataFrame:
    """Read a generated CSV with exact values: strings stay strings, empty stays '', numbers are typed."""
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    for col in INT_COLUMNS & set(df.columns):
        df[col] = df[col].astype("int64")
    for col in FLOAT_COLUMNS & set(df.columns):
        df[col] = df[col].astype("float64")
    return df


def write_csv(df: pd.DataFrame, path: Path) -> None:
    """Write one CSV (UTF-8, LF line endings, no index) creating folders as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, lineterminator="\n", encoding="utf-8")


def clean_output(output_dir: Path) -> None:
    """Remove only the folders this generator creates, so reruns never leave stale batches."""
    if not output_dir.exists():
        return
    for child in output_dir.iterdir():
        if child.is_dir() and (child.name in GENERATED_DIRS or BATCH_DIR.fullmatch(child.name)):
            shutil.rmtree(child)


def collect_files(ds: GeneratedDataset) -> dict[str, pd.DataFrame]:
    """Map relative output path -> frame, in a fixed order."""
    files: dict[str, pd.DataFrame] = {"reference/pharmacies.csv": ds.pharmacies}
    first = next(iter(ds.delivery_batches))
    files[f"{first}/orders.csv"] = ds.orders
    files[f"{first}/order_lines.csv"] = ds.order_lines
    files[f"{first}/shipment_lines.csv"] = ds.shipment_lines
    for name, frame in ds.delivery_batches.items():
        files[f"{name}/delivery_events.csv"] = frame
    fx = ds.fixture
    files["fixture/orders.csv"] = fx.orders
    files["fixture/order_lines.csv"] = fx.order_lines
    files["fixture/shipment_lines.csv"] = fx.shipment_lines
    files["fixture/delivery_events.csv"] = fx.delivery_events
    files["fixture/expected_results.csv"] = fx.expected_results
    files["metadata/test_manifest.csv"] = ds.manifest
    return files


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_dataset(ds: GeneratedDataset, output_dir: Path) -> list[Path]:
    """Write every CSV plus metadata/run_summary.json. Returns all written paths."""
    files = collect_files(ds)
    clean_output(output_dir)

    written: list[Path] = []
    row_counts: dict[str, int] = {}
    checksums: dict[str, str] = {}
    for rel, frame in files.items():
        path = output_dir / rel
        write_csv(frame, path)
        written.append(path)
        row_counts[rel] = len(frame)
        checksums[rel] = _sha256(path)

    config = ds.config.to_dict()
    config.pop("output_dir", None)  # keep the summary identical regardless of where it is written
    summary = {
        "config": config,
        "row_counts": row_counts,
        "manifest_counts": ds.manifest.groupby(["dataset", "reason"]).size().rename("n").reset_index()
        .assign(key=lambda d: d["dataset"] + "/" + d["reason"]).set_index("key")["n"].astype(int).to_dict(),
        "sha256": checksums,
    }
    summary_path = output_dir / "metadata" / "run_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    written.append(summary_path)
    return written
