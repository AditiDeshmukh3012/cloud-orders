"""Orchestrates one generator run: build -> validate -> reproducibility check -> write."""
from __future__ import annotations

import logging

import pandas as pd

from data_generator.config import GeneratorConfig
from data_generator.dataset import GeneratedDataset
from data_generator.generators.delivery_events import generate_delivery_events
from data_generator.generators.fixtures import generate_fixture
from data_generator.generators.order_lines import generate_order_lines
from data_generator.generators.orders import generate_orders
from data_generator.generators.pharmacies import generate_pharmacies
from data_generator.generators.shipments import generate_shipments
from data_generator.manifest import manifest_frame
from data_generator.validation.referential_integrity import GeneratorValidationError, validate_dataset
from data_generator.writer import write_dataset

logger = logging.getLogger(__name__)


def build_dataset(config: GeneratorConfig) -> GeneratedDataset:
    """Generate every table in memory. Pure function of the config (and its seed)."""
    pharmacies = generate_pharmacies(config)
    orders = generate_orders(config, pharmacies["pharmacy_id"].tolist())
    lines = generate_order_lines(config, orders.scenarios)
    shipments = generate_shipments(config, lines.order_lines, orders.scenarios)
    events = generate_delivery_events(config, orders.orders, shipments.plan)

    manifest = manifest_frame(orders.manifest + lines.manifest + events.manifest)
    manifest = manifest.sort_values(["dataset", "batch", "reason", "record_key"], kind="mergesort").reset_index(drop=True)

    return GeneratedDataset(
        config=config,
        pharmacies=pharmacies,
        orders=orders.orders,
        order_lines=lines.order_lines,
        shipment_lines=shipments.shipment_lines,
        delivery_batches=events.batches,
        manifest=manifest,
        fixture=generate_fixture(),
    )


def _frames(ds: GeneratedDataset) -> dict[str, pd.DataFrame]:
    frames = {
        "pharmacies": ds.pharmacies,
        "orders": ds.orders,
        "order_lines": ds.order_lines,
        "shipment_lines": ds.shipment_lines,
        "manifest": ds.manifest,
        "fixture/orders": ds.fixture.orders,
        "fixture/order_lines": ds.fixture.order_lines,
        "fixture/shipment_lines": ds.fixture.shipment_lines,
        "fixture/delivery_events": ds.fixture.delivery_events,
        "fixture/expected_results": ds.fixture.expected_results,
    }
    for name, frame in ds.delivery_batches.items():
        frames[f"delivery_events/{name}"] = frame
    return frames


def differing_frames(a: GeneratedDataset, b: GeneratedDataset) -> list[str]:
    """Names of frames that differ between two datasets (empty list = identical)."""
    fa, fb = _frames(a), _frames(b)
    names = sorted(set(fa) | set(fb))
    return [n for n in names if n not in fa or n not in fb or not fa[n].equals(fb[n])]


def datasets_equal(a: GeneratedDataset, b: GeneratedDataset) -> bool:
    return not differing_frames(a, b)


def run(config: GeneratorConfig, check_reproducibility: bool = True) -> GeneratedDataset:
    """Build, validate and write the dataset. Raises GeneratorValidationError on any unexpected defect."""
    logger.info("Generating data (seed=%s, orders=%s, batches=%s)", config.seed, config.orders, config.batches)
    dataset = build_dataset(config)

    report = validate_dataset(dataset)
    for warning in report.warnings:
        logger.warning(warning)
    report.raise_if_failed()
    logger.info("Validation passed (%d checks, %d warnings)", report.checks_run, len(report.warnings))

    if check_reproducibility:
        differing = differing_frames(dataset, build_dataset(config))
        if differing:
            raise GeneratorValidationError(f"Output is not reproducible; differing tables: {differing}")
        logger.info("Reproducibility check passed (two independent builds are identical)")

    paths = write_dataset(dataset, config.output_path)
    logger.info("Wrote %d files under %s", len(paths), config.output_path.resolve())
    for name, frame in dataset.delivery_batches.items():
        logger.info("  %s/delivery_events.csv: %d rows", name, len(frame))
    logger.info("  test manifest entries: %d", len(dataset.manifest))
    return dataset
