"""Command-line interface."""
from __future__ import annotations

import argparse
import logging
import sys

from data_generator.config import GeneratorConfig
from data_generator.pipeline import run
from data_generator.validation.referential_integrity import GeneratorValidationError

logger = logging.getLogger("data_generator")
_NOT_CONFIG = {"skip_reproducibility_check", "log_level"}


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser. Unset options fall back to GeneratorConfig defaults."""
    d = GeneratorConfig()
    s = argparse.SUPPRESS  # option absent from the namespace unless the user passes it
    p = argparse.ArgumentParser(
        prog="generate_data.py",
        description="Synthetic data generator for the Cencora pharmacy order fulfilment capstone.",
    )
    p.add_argument("--seed", type=int, default=s, help=f"random seed (default: {d.seed})")
    p.add_argument("--pharmacies", type=int, default=s, help=f"number of pharmacies (default: {d.pharmacies})")
    p.add_argument("--products", type=int, default=s, help=f"number of products (default: {d.products})")
    p.add_argument("--orders", type=int, default=s, help=f"number of valid orders (default: {d.orders})")
    p.add_argument("--start-date", default=s, help=f"earliest order date, YYYY-MM-DD (default: {d.start_date})")
    p.add_argument("--end-date", default=s, help=f"latest order date, YYYY-MM-DD (default: {d.end_date})")
    p.add_argument("--batches", type=int, default=s, help=f"number of delivery batches (default: {d.batches})")
    p.add_argument("--incremental-batch-min", type=int, default=s,
                   help=f"min events in batch_002 and later (default: {d.incremental_batch_min})")
    p.add_argument("--incremental-batch-max", type=int, default=s,
                   help=f"max events in batch_002 and later (default: {d.incremental_batch_max})")
    p.add_argument("--output-dir", default=s, help=f"output folder (default: {d.output_dir})")
    for name, default in d.invalid_rates().items():
        p.add_argument("--" + name.replace("_", "-"), dest=name, type=float, default=s,
                       help=f"bad-record rate as a fraction between 0 and 0.2 (default: {default})")
    p.add_argument("--skip-reproducibility-check", action="store_true",
                   help="skip building the dataset a second time to prove it is identical")
    p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return p


def config_from_args(args: argparse.Namespace) -> GeneratorConfig:
    """Create a validated config from the parsed options."""
    return GeneratorConfig(**{k: v for k, v in vars(args).items() if k not in _NOT_CONFIG})


def main(argv: list[str] | None = None) -> int:
    """Entry point. Returns a process exit code."""
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=args.log_level, format="%(levelname)s %(name)s: %(message)s", stream=sys.stdout)
    try:
        config = config_from_args(args)
    except ValueError as exc:
        logger.error("Invalid configuration: %s", exc)
        return 2
    try:
        run(config, check_reproducibility=not args.skip_reproducibility_check)
    except (ValueError, GeneratorValidationError) as exc:
        logger.error("%s", exc)
        return 1
    return 0
