"""Test manifest: records WHY each deliberately bad record exists.

The manifest is written to a separate file so the required source schemas
stay clean. Validation uses it to tell intentional bad records apart from
accidental generator bugs, and Silver-layer tests can use it as an answer key.
"""
from __future__ import annotations

import pandas as pd

MANIFEST_COLUMNS = ["dataset", "batch", "record_key", "reason", "expected_treatment"]

# Reasons
UNKNOWN_PHARMACY = "unknown_pharmacy"
MISSING_ORDER_ID = "missing_order_id"
MISSING_LINE_ID = "missing_line_id"
NONPOSITIVE_QUANTITY = "nonpositive_quantity"
NEGATIVE_DELIVERY = "negative_delivery"
UNKNOWN_SHIPMENT_LINE = "unknown_shipment_line"
DUPLICATE_EVENT_ID = "duplicate_event_id"
DELIVERY_BEFORE_ORDER = "delivery_before_order"
OVERDELIVERY = "overdelivery"

# Expected downstream treatment
REJECT = "reject"
QUARANTINE = "quarantine"
DEDUPLICATE = "deduplicate"
FLAG = "flag"


def entry(dataset: str, batch: str, record_key: str, reason: str, treatment: str) -> dict[str, str]:
    """Build one manifest row."""
    return {
        "dataset": dataset,
        "batch": batch,
        "record_key": record_key,
        "reason": reason,
        "expected_treatment": treatment,
    }


def manifest_frame(entries: list[dict[str, str]]) -> pd.DataFrame:
    """Convert manifest entries to a DataFrame with the fixed column order."""
    return pd.DataFrame(entries, columns=MANIFEST_COLUMNS)
