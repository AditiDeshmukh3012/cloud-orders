"""Container for everything one generator run produces."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from data_generator.config import GeneratorConfig
from data_generator.generators.fixtures import FixtureData


@dataclass
class GeneratedDataset:
    """All generated tables, in memory, before they are written to disk."""

    config: GeneratorConfig
    pharmacies: pd.DataFrame
    orders: pd.DataFrame
    order_lines: pd.DataFrame
    shipment_lines: pd.DataFrame
    delivery_batches: dict[str, pd.DataFrame]  # 'batch_001' -> delivery_events frame
    manifest: pd.DataFrame
    fixture: FixtureData
