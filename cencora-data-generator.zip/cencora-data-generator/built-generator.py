# Databricks notebook source
# MAGIC %sh
# MAGIC pwd
# MAGIC python --version

# COMMAND ----------

# MAGIC %sh
# MAGIC mkdir -p src/data_generator/generators src/data_generator/validation src/data_generator/utils tests output
# MAGIC touch README.md generate_data.py
# MAGIC touch src/data_generator/__init__.py
# MAGIC touch src/data_generator/generators/__init__.py src/data_generator/validation/__init__.py src/data_generator/utils/__init__.py
# MAGIC find . -type f -not -name "*.ipynb" | sort

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > requirements.txt << 'EOF'
# MAGIC pandas>=2.0
# MAGIC pytest>=7.4
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > pyproject.toml << 'EOF'
# MAGIC [build-system]
# MAGIC requires = ["setuptools>=68"]
# MAGIC build-backend = "setuptools.build_meta"
# MAGIC
# MAGIC [project]
# MAGIC name = "data_generator"
# MAGIC version = "0.1.0"
# MAGIC description = "Synthetic data generator for the Cencora pharmacy order fulfilment capstone"
# MAGIC requires-python = ">=3.11"
# MAGIC dependencies = ["pandas>=2.0"]
# MAGIC
# MAGIC [tool.setuptools.packages.find]
# MAGIC where = ["src"]
# MAGIC
# MAGIC [tool.pytest.ini_options]
# MAGIC pythonpath = ["src"]
# MAGIC testpaths = ["tests"]
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/utils/random_utils.py << 'EOF'
# MAGIC """Deterministic random helpers.
# MAGIC
# MAGIC Every generator gets its own random.Random instance derived from the single
# MAGIC user-facing seed plus a namespace string. This keeps each generator
# MAGIC reproducible AND independent: changing how many random numbers one generator
# MAGIC consumes does not shift the numbers seen by another.
# MAGIC
# MAGIC hashlib is used (not the built-in hash()) because hash() of strings is
# MAGIC randomised per Python process and would break reproducibility.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import hashlib
# MAGIC import random
# MAGIC from datetime import datetime, timedelta, timezone
# MAGIC from typing import Sequence, TypeVar
# MAGIC
# MAGIC T = TypeVar("T")
# MAGIC
# MAGIC TS_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
# MAGIC
# MAGIC
# MAGIC def derive_seed(base_seed: int, namespace: str) -> int:
# MAGIC     """Derive a stable 64-bit seed from a base seed and a namespace."""
# MAGIC     digest = hashlib.sha256(f"{base_seed}:{namespace}".encode("utf-8")).digest()
# MAGIC     return int.from_bytes(digest[:8], "big")
# MAGIC
# MAGIC
# MAGIC def make_rng(base_seed: int, namespace: str) -> random.Random:
# MAGIC     """Create an independent, deterministic RNG for the given namespace."""
# MAGIC     return random.Random(derive_seed(base_seed, namespace))
# MAGIC
# MAGIC
# MAGIC def weighted_choice(rng: random.Random, items: Sequence[T], weights: Sequence[float]) -> T:
# MAGIC     """Pick one item using relative weights."""
# MAGIC     return rng.choices(list(items), weights=list(weights), k=1)[0]
# MAGIC
# MAGIC
# MAGIC def random_datetime(rng: random.Random, start: datetime, end: datetime) -> datetime:
# MAGIC     """Return a random UTC datetime in [start, end], truncated to whole seconds."""
# MAGIC     if end < start:
# MAGIC         raise ValueError("end must not be earlier than start")
# MAGIC     span_seconds = int((end - start).total_seconds())
# MAGIC     return start.replace(microsecond=0) + timedelta(seconds=rng.randint(0, span_seconds))
# MAGIC
# MAGIC
# MAGIC def format_ts(value: datetime) -> str:
# MAGIC     """Format a datetime as ISO-8601 UTC, e.g. 2026-10-01T10:30:00Z."""
# MAGIC     if value.tzinfo is None:
# MAGIC         value = value.replace(tzinfo=timezone.utc)
# MAGIC     return value.astimezone(timezone.utc).strftime(TS_FORMAT)
# MAGIC
# MAGIC
# MAGIC def parse_ts(value: str) -> datetime:
# MAGIC     """Parse a timestamp produced by format_ts back into an aware datetime."""
# MAGIC     return datetime.strptime(value, TS_FORMAT).replace(tzinfo=timezone.utc)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/utils/ids.py << 'EOF'
# MAGIC """Deterministic ID builders. All IDs are strings.
# MAGIC
# MAGIC An optional prefix lets the known-result fixture use its own ID space
# MAGIC (e.g. "FX-") so fixture IDs can never collide with main-dataset IDs.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC
# MAGIC def pharmacy_id(n: int) -> str:
# MAGIC     return f"PH-{n:04d}"
# MAGIC
# MAGIC
# MAGIC def product_id(n: int) -> str:
# MAGIC     return f"PRD-{n:04d}"
# MAGIC
# MAGIC
# MAGIC def order_id(n: int, prefix: str = "") -> str:
# MAGIC     return f"{prefix}ORD-{n:06d}"
# MAGIC
# MAGIC
# MAGIC def line_id(n: int) -> str:
# MAGIC     """Line IDs are only unique within an order: L01, L02, ..."""
# MAGIC     return f"L{n:02d}"
# MAGIC
# MAGIC
# MAGIC def shipment_id(n: int, prefix: str = "") -> str:
# MAGIC     return f"{prefix}SHP-{n:06d}"
# MAGIC
# MAGIC
# MAGIC def event_id(n: int, prefix: str = "") -> str:
# MAGIC     return f"{prefix}EVT-{n:07d}"
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/config.py << 'EOF'
# MAGIC """Configuration and schema definitions for the data generator."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC from dataclasses import asdict, dataclass
# MAGIC from datetime import datetime, timezone
# MAGIC from pathlib import Path
# MAGIC
# MAGIC DEFAULT_SEED = 42
# MAGIC
# MAGIC # Required source schemas (column order = CSV column order).
# MAGIC # No test-explanation columns are ever added to these.
# MAGIC ORDERS_COLUMNS = ["order_id", "pharmacy_id", "order_time", "promised_delivery_time", "order_status"]
# MAGIC ORDER_LINES_COLUMNS = ["order_id", "line_id", "product_id", "ordered_quantity"]
# MAGIC SHIPMENT_LINES_COLUMNS = ["shipment_id", "order_id", "line_id", "shipped_quantity"]
# MAGIC DELIVERY_EVENTS_COLUMNS = ["event_id", "shipment_id", "order_id", "line_id", "delivered_quantity", "delivery_time"]
# MAGIC PHARMACIES_COLUMNS = ["pharmacy_id", "region", "contact_name", "contact_email"]
# MAGIC EXPECTED_RESULTS_COLUMNS = [
# MAGIC     "order_id",
# MAGIC     "expected_fulfilment_percent",
# MAGIC     "expected_otif",
# MAGIC     "expected_open_units",
# MAGIC     "expected_overdelivery_flag",
# MAGIC ]
# MAGIC
# MAGIC SCHEMAS: dict[str, list[str]] = {
# MAGIC     "orders": ORDERS_COLUMNS,
# MAGIC     "order_lines": ORDER_LINES_COLUMNS,
# MAGIC     "shipment_lines": SHIPMENT_LINES_COLUMNS,
# MAGIC     "delivery_events": DELIVERY_EVENTS_COLUMNS,
# MAGIC     "pharmacies": PHARMACIES_COLUMNS,
# MAGIC }
# MAGIC
# MAGIC REGIONS = ["North", "South", "East", "West", "Central"]
# MAGIC ORDER_STATUSES = ["OPEN", "CANCELLED", "COMPLETED"]
# MAGIC
# MAGIC
# MAGIC @dataclass(frozen=True)
# MAGIC class GeneratorConfig:
# MAGIC     """All tunable settings. Same config + same seed => identical output."""
# MAGIC
# MAGIC     seed: int = DEFAULT_SEED
# MAGIC     pharmacies: int = 100
# MAGIC     products: int = 200
# MAGIC     orders: int = 2000
# MAGIC     start_date: str = "2026-08-01"   # earliest order_time (UTC)
# MAGIC     end_date: str = "2026-09-20"     # latest order_time (UTC)
# MAGIC     batches: int = 3                 # batch_001 = baseline load, rest = incremental
# MAGIC     incremental_batch_min: int = 100  # min delivery events in batch_002+
# MAGIC     incremental_batch_max: int = 500  # max delivery events in batch_002+
# MAGIC     output_dir: str = "output"
# MAGIC
# MAGIC     # Order outcome mix (must sum to 1.0)
# MAGIC     on_time_pct: float = 0.50
# MAGIC     late_pct: float = 0.20
# MAGIC     open_pct: float = 0.25
# MAGIC     cancelled_pct: float = 0.05
# MAGIC
# MAGIC     # Controlled bad-record rates (fraction of the relevant rows)
# MAGIC     overdelivery_pct: float = 0.02
# MAGIC     early_delivery_pct: float = 0.01
# MAGIC     duplicate_event_pct: float = 0.02
# MAGIC     unknown_pharmacy_pct: float = 0.01
# MAGIC     missing_id_pct: float = 0.01
# MAGIC     nonpositive_quantity_pct: float = 0.01
# MAGIC     negative_delivery_pct: float = 0.01
# MAGIC     unknown_shipment_pct: float = 0.01
# MAGIC
# MAGIC     def __post_init__(self) -> None:
# MAGIC         if self.pharmacies < 1 or self.products < 1 or self.orders < 1:
# MAGIC             raise ValueError("pharmacies, products and orders must be >= 1")
# MAGIC         if self.batches < 1:
# MAGIC             raise ValueError("batches must be >= 1")
# MAGIC         if not 0 < self.incremental_batch_min <= self.incremental_batch_max:
# MAGIC             raise ValueError("need 0 < incremental_batch_min <= incremental_batch_max")
# MAGIC         if self.start_dt >= self.end_dt:
# MAGIC             raise ValueError("start_date must be earlier than end_date")
# MAGIC         mix = self.on_time_pct + self.late_pct + self.open_pct + self.cancelled_pct
# MAGIC         if abs(mix - 1.0) > 1e-9:
# MAGIC             raise ValueError(f"order outcome mix must sum to 1.0, got {mix}")
# MAGIC         for name, value in self.invalid_rates().items():
# MAGIC             if not 0.0 <= value <= 0.2:
# MAGIC                 raise ValueError(f"{name} must be between 0 and 0.2 (bad records must stay a minority)")
# MAGIC
# MAGIC     @property
# MAGIC     def start_dt(self) -> datetime:
# MAGIC         return datetime.strptime(self.start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
# MAGIC
# MAGIC     @property
# MAGIC     def end_dt(self) -> datetime:
# MAGIC         return datetime.strptime(self.end_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
# MAGIC
# MAGIC     @property
# MAGIC     def output_path(self) -> Path:
# MAGIC         return Path(self.output_dir)
# MAGIC
# MAGIC     def invalid_rates(self) -> dict[str, float]:
# MAGIC         """All controlled bad-record percentages in one place."""
# MAGIC         return {
# MAGIC             "overdelivery_pct": self.overdelivery_pct,
# MAGIC             "early_delivery_pct": self.early_delivery_pct,
# MAGIC             "duplicate_event_pct": self.duplicate_event_pct,
# MAGIC             "unknown_pharmacy_pct": self.unknown_pharmacy_pct,
# MAGIC             "missing_id_pct": self.missing_id_pct,
# MAGIC             "nonpositive_quantity_pct": self.nonpositive_quantity_pct,
# MAGIC             "negative_delivery_pct": self.negative_delivery_pct,
# MAGIC             "unknown_shipment_pct": self.unknown_shipment_pct,
# MAGIC         }
# MAGIC
# MAGIC     def to_dict(self) -> dict:
# MAGIC         return asdict(self)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install -q -r requirements.txt
# MAGIC PYTHONPATH=src python -c "
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.utils.ids import order_id, line_id, event_id
# MAGIC from data_generator.utils.random_utils import make_rng, random_datetime, format_ts
# MAGIC c = GeneratorConfig()
# MAGIC r = make_rng(c.seed, 'test')
# MAGIC print(order_id(1), line_id(1), event_id(1))
# MAGIC print(format_ts(random_datetime(r, c.start_dt, c.end_dt)))
# MAGIC "

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/manifest.py << 'EOF'
# MAGIC """Test manifest: records WHY each deliberately bad record exists.
# MAGIC
# MAGIC The manifest is written to a separate file so the required source schemas
# MAGIC stay clean. Validation uses it to tell intentional bad records apart from
# MAGIC accidental generator bugs, and Silver-layer tests can use it as an answer key.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC MANIFEST_COLUMNS = ["dataset", "batch", "record_key", "reason", "expected_treatment"]
# MAGIC
# MAGIC # Reasons
# MAGIC UNKNOWN_PHARMACY = "unknown_pharmacy"
# MAGIC MISSING_ORDER_ID = "missing_order_id"
# MAGIC MISSING_LINE_ID = "missing_line_id"
# MAGIC NONPOSITIVE_QUANTITY = "nonpositive_quantity"
# MAGIC NEGATIVE_DELIVERY = "negative_delivery"
# MAGIC UNKNOWN_SHIPMENT_LINE = "unknown_shipment_line"
# MAGIC DUPLICATE_EVENT_ID = "duplicate_event_id"
# MAGIC DELIVERY_BEFORE_ORDER = "delivery_before_order"
# MAGIC OVERDELIVERY = "overdelivery"
# MAGIC
# MAGIC # Expected downstream treatment
# MAGIC REJECT = "reject"
# MAGIC QUARANTINE = "quarantine"
# MAGIC DEDUPLICATE = "deduplicate"
# MAGIC FLAG = "flag"
# MAGIC
# MAGIC
# MAGIC def entry(dataset: str, batch: str, record_key: str, reason: str, treatment: str) -> dict[str, str]:
# MAGIC     """Build one manifest row."""
# MAGIC     return {
# MAGIC         "dataset": dataset,
# MAGIC         "batch": batch,
# MAGIC         "record_key": record_key,
# MAGIC         "reason": reason,
# MAGIC         "expected_treatment": treatment,
# MAGIC     }
# MAGIC
# MAGIC
# MAGIC def manifest_frame(entries: list[dict[str, str]]) -> pd.DataFrame:
# MAGIC     """Convert manifest entries to a DataFrame with the fixed column order."""
# MAGIC     return pd.DataFrame(entries, columns=MANIFEST_COLUMNS)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/utils/counts.py << 'EOF'
# MAGIC """Small deterministic helpers for counts and quantity splitting."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import random
# MAGIC
# MAGIC
# MAGIC def rate_count(total: int, rate: float) -> int:
# MAGIC     """Number of records for a percentage rate; at least 1 when the rate is > 0."""
# MAGIC     if rate <= 0 or total <= 0:
# MAGIC         return 0
# MAGIC     return max(1, int(round(total * rate)))
# MAGIC
# MAGIC
# MAGIC def allocate_counts(total: int, fractions: dict[str, float]) -> dict[str, int]:
# MAGIC     """Split `total` across keys using the largest-remainder method.
# MAGIC
# MAGIC     Counts always sum exactly to `total`. When there is room, every key with a
# MAGIC     positive fraction gets at least one item so every scenario exists.
# MAGIC     """
# MAGIC     keys = list(fractions)
# MAGIC     raw = {k: total * fractions[k] for k in keys}
# MAGIC     counts = {k: int(raw[k]) for k in keys}
# MAGIC     leftover = total - sum(counts.values())
# MAGIC     by_remainder = sorted(keys, key=lambda k: (-(raw[k] - counts[k]), keys.index(k)))
# MAGIC     for k in by_remainder[:leftover]:
# MAGIC         counts[k] += 1
# MAGIC     if total >= len(keys):
# MAGIC         for k in keys:
# MAGIC             if fractions[k] > 0 and counts[k] == 0:
# MAGIC                 donor = max(keys, key=lambda x: counts[x])
# MAGIC                 counts[donor] -= 1
# MAGIC                 counts[k] += 1
# MAGIC     return counts
# MAGIC
# MAGIC
# MAGIC def split_quantity(rng: random.Random, quantity: int, low: float = 0.4, high: float = 0.7) -> int:
# MAGIC     """Return a first part strictly between 1 and quantity-1 (both parts >= 1)."""
# MAGIC     if quantity < 2:
# MAGIC         raise ValueError("quantity must be at least 2 to split")
# MAGIC     part = int(round(quantity * rng.uniform(low, high)))
# MAGIC     return min(max(part, 1), quantity - 1)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/pharmacies.py << 'EOF'
# MAGIC """Pharmacy reference table (includes restricted synthetic contact data)."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import PHARMACIES_COLUMNS, REGIONS, GeneratorConfig
# MAGIC from data_generator.utils.ids import pharmacy_id
# MAGIC from data_generator.utils.random_utils import make_rng
# MAGIC
# MAGIC FIRST_NAMES = [
# MAGIC     "Alice", "Brian", "Chloe", "Daniel", "Elena", "Farid", "Grace", "Hugo", "Isla", "Jamal",
# MAGIC     "Keiko", "Liam", "Maya", "Noah", "Olivia", "Priya", "Quinn", "Rosa", "Samir", "Tara",
# MAGIC ]
# MAGIC LAST_NAMES = [
# MAGIC     "Anderson", "Brooks", "Carter", "Dawson", "Ellis", "Foster", "Grant", "Hughes", "Ibrahim", "Jensen",
# MAGIC     "Kapoor", "Lopez", "Morgan", "Nguyen", "Okafor", "Patel", "Reyes", "Sullivan", "Turner", "Walker",
# MAGIC ]
# MAGIC EMAIL_DOMAIN = "example.test"  # reserved test domain: never a real mailbox
# MAGIC
# MAGIC
# MAGIC def generate_pharmacies(config: GeneratorConfig) -> pd.DataFrame:
# MAGIC     """Generate `config.pharmacies` pharmacies.
# MAGIC
# MAGIC     Regions are assigned round-robin so every region is represented.
# MAGIC     contact_name and contact_email are fully synthetic and classified as
# MAGIC     restricted data later in the governance work.
# MAGIC     """
# MAGIC     rng = make_rng(config.seed, "pharmacies")
# MAGIC     rows = []
# MAGIC     for n in range(1, config.pharmacies + 1):
# MAGIC         first = rng.choice(FIRST_NAMES)
# MAGIC         last = rng.choice(LAST_NAMES)
# MAGIC         rows.append(
# MAGIC             {
# MAGIC                 "pharmacy_id": pharmacy_id(n),
# MAGIC                 "region": REGIONS[(n - 1) % len(REGIONS)],
# MAGIC                 "contact_name": f"{first} {last}",
# MAGIC                 "contact_email": f"{first}.{last}.{n}@{EMAIL_DOMAIN}".lower(),
# MAGIC             }
# MAGIC         )
# MAGIC     return pd.DataFrame(rows, columns=PHARMACIES_COLUMNS)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/pharmacies.py << 'EOF'
# MAGIC """Pharmacy reference table (includes restricted synthetic contact data)."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import PHARMACIES_COLUMNS, REGIONS, GeneratorConfig
# MAGIC from data_generator.utils.ids import pharmacy_id
# MAGIC from data_generator.utils.random_utils import make_rng
# MAGIC
# MAGIC FIRST_NAMES = [
# MAGIC     "Alice", "Brian", "Chloe", "Daniel", "Elena", "Farid", "Grace", "Hugo", "Isla", "Jamal",
# MAGIC     "Keiko", "Liam", "Maya", "Noah", "Olivia", "Priya", "Quinn", "Rosa", "Samir", "Tara",
# MAGIC ]
# MAGIC LAST_NAMES = [
# MAGIC     "Anderson", "Brooks", "Carter", "Dawson", "Ellis", "Foster", "Grant", "Hughes", "Ibrahim", "Jensen",
# MAGIC     "Kapoor", "Lopez", "Morgan", "Nguyen", "Okafor", "Patel", "Reyes", "Sullivan", "Turner", "Walker",
# MAGIC ]
# MAGIC EMAIL_DOMAIN = "example.test"  # reserved test domain: never a real mailbox
# MAGIC
# MAGIC
# MAGIC def generate_pharmacies(config: GeneratorConfig) -> pd.DataFrame:
# MAGIC     """Generate `config.pharmacies` pharmacies.
# MAGIC
# MAGIC     Regions are assigned round-robin so every region is represented.
# MAGIC     contact_name and contact_email are fully synthetic and classified as
# MAGIC     restricted data later in the governance work.
# MAGIC     """
# MAGIC     rng = make_rng(config.seed, "pharmacies")
# MAGIC     rows = []
# MAGIC     for n in range(1, config.pharmacies + 1):
# MAGIC         first = rng.choice(FIRST_NAMES)
# MAGIC         last = rng.choice(LAST_NAMES)
# MAGIC         rows.append(
# MAGIC             {
# MAGIC                 "pharmacy_id": pharmacy_id(n),
# MAGIC                 "region": REGIONS[(n - 1) % len(REGIONS)],
# MAGIC                 "contact_name": f"{first} {last}",
# MAGIC                 "contact_email": f"{first}.{last}.{n}@{EMAIL_DOMAIN}".lower(),
# MAGIC             }
# MAGIC         )
# MAGIC     return pd.DataFrame(rows, columns=PHARMACIES_COLUMNS)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/orders.py << 'EOF'
# MAGIC """Orders table: valid orders plus a controlled minority of bad order records.
# MAGIC
# MAGIC Every valid order is assigned a scenario (on_time / late / open / cancelled)
# MAGIC using exact counts. The scenario drives how shipments and delivery events are
# MAGIC generated later, but it is NOT written to the CSV.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import random
# MAGIC from dataclasses import dataclass
# MAGIC from datetime import datetime, timedelta
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import ORDERS_COLUMNS, GeneratorConfig
# MAGIC from data_generator.manifest import MISSING_ORDER_ID, REJECT, UNKNOWN_PHARMACY, entry
# MAGIC from data_generator.utils.counts import allocate_counts, rate_count
# MAGIC from data_generator.utils.ids import order_id, pharmacy_id
# MAGIC from data_generator.utils.random_utils import format_ts, make_rng, random_datetime
# MAGIC
# MAGIC BATCH_1 = "batch_001"
# MAGIC
# MAGIC # Scenarios for valid orders
# MAGIC ON_TIME = "on_time"
# MAGIC LATE = "late"
# MAGIC OPEN = "open"
# MAGIC CANCELLED = "cancelled"
# MAGIC VALID_SCENARIOS = (ON_TIME, LATE, OPEN, CANCELLED)
# MAGIC
# MAGIC # Scenarios for dedicated invalid-record orders (reserved ID range)
# MAGIC UNKNOWN_PHARMACY_ORDER = "unknown_pharmacy"
# MAGIC BAD_QUANTITY_ORDER = "bad_quantity"
# MAGIC MISSING_LINE_ID_ORDER = "missing_line_id"
# MAGIC
# MAGIC INVALID_ORDER_START = 900000  # invalid-record orders are ORD-900001 and up
# MAGIC LEAD_TIME_HOURS = [48, 72, 96, 120]
# MAGIC
# MAGIC STATUS_BY_SCENARIO = {
# MAGIC     ON_TIME: "COMPLETED",
# MAGIC     LATE: "OPEN",  # still open at the batch_001 load; completes in a later batch
# MAGIC     OPEN: "OPEN",
# MAGIC     CANCELLED: "CANCELLED",
# MAGIC }
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class OrdersResult:
# MAGIC     """Orders table plus the internal scenario map and test manifest entries."""
# MAGIC
# MAGIC     orders: pd.DataFrame
# MAGIC     scenarios: dict[str, str]  # order_id -> scenario (internal only)
# MAGIC     manifest: list[dict[str, str]]
# MAGIC
# MAGIC
# MAGIC def _make_row(oid: str, pharmacy: str, order_time: datetime, lead_hours: int, status: str) -> dict[str, str]:
# MAGIC     return {
# MAGIC         "order_id": oid,
# MAGIC         "pharmacy_id": pharmacy,
# MAGIC         "order_time": format_ts(order_time),
# MAGIC         "promised_delivery_time": format_ts(order_time + timedelta(hours=lead_hours)),
# MAGIC         "order_status": status,
# MAGIC     }
# MAGIC
# MAGIC
# MAGIC def _random_row(rng: random.Random, config: GeneratorConfig, oid: str, pharmacy: str, status: str) -> dict[str, str]:
# MAGIC     order_time = random_datetime(rng, config.start_dt, config.end_dt)
# MAGIC     return _make_row(oid, pharmacy, order_time, rng.choice(LEAD_TIME_HOURS), status)
# MAGIC
# MAGIC
# MAGIC def _unknown_pharmacy_id(known: set[str], k: int) -> str:
# MAGIC     """A pharmacy ID guaranteed not to exist in the pharmacies table."""
# MAGIC     n = 9000 + k
# MAGIC     while pharmacy_id(n) in known:
# MAGIC         n += 1
# MAGIC     pid = pharmacy_id(n)
# MAGIC     known.add(pid)
# MAGIC     return pid
# MAGIC
# MAGIC
# MAGIC def generate_orders(config: GeneratorConfig, pharmacy_ids: list[str]) -> OrdersResult:
# MAGIC     """Generate valid orders and controlled invalid order records."""
# MAGIC     if config.orders >= INVALID_ORDER_START:
# MAGIC         raise ValueError(f"orders must be below {INVALID_ORDER_START}")
# MAGIC
# MAGIC     rng = make_rng(config.seed, "orders")
# MAGIC     rows: list[dict[str, str]] = []
# MAGIC     scenarios: dict[str, str] = {}
# MAGIC     manifest: list[dict[str, str]] = []
# MAGIC
# MAGIC     # --- valid orders: exact scenario counts, shuffled, with ascending order times
# MAGIC     counts = allocate_counts(
# MAGIC         config.orders,
# MAGIC         {
# MAGIC             ON_TIME: config.on_time_pct,
# MAGIC             LATE: config.late_pct,
# MAGIC             OPEN: config.open_pct,
# MAGIC             CANCELLED: config.cancelled_pct,
# MAGIC         },
# MAGIC     )
# MAGIC     plan = [s for s in VALID_SCENARIOS for _ in range(counts[s])]
# MAGIC     rng.shuffle(plan)
# MAGIC     times = sorted(random_datetime(rng, config.start_dt, config.end_dt) for _ in range(config.orders))
# MAGIC     for i, (scenario, order_time) in enumerate(zip(plan, times), start=1):
# MAGIC         oid = order_id(i)
# MAGIC         pharmacy = rng.choice(pharmacy_ids)
# MAGIC         rows.append(_make_row(oid, pharmacy, order_time, rng.choice(LEAD_TIME_HOURS), STATUS_BY_SCENARIO[scenario]))
# MAGIC         scenarios[oid] = scenario
# MAGIC
# MAGIC     # --- invalid: orders referencing an unknown pharmacy
# MAGIC     next_no = INVALID_ORDER_START
# MAGIC     known = set(pharmacy_ids)
# MAGIC     for k in range(rate_count(config.orders, config.unknown_pharmacy_pct)):
# MAGIC         next_no += 1
# MAGIC         oid = order_id(next_no)
# MAGIC         rows.append(_random_row(rng, config, oid, _unknown_pharmacy_id(known, k), "OPEN"))
# MAGIC         scenarios[oid] = UNKNOWN_PHARMACY_ORDER
# MAGIC         manifest.append(entry("orders", BATCH_1, oid, UNKNOWN_PHARMACY, REJECT))
# MAGIC
# MAGIC     # --- valid orders that exist only to carry one bad order line each
# MAGIC     for kind, rate in (
# MAGIC         (BAD_QUANTITY_ORDER, config.nonpositive_quantity_pct),
# MAGIC         (MISSING_LINE_ID_ORDER, config.missing_id_pct),
# MAGIC     ):
# MAGIC         for _ in range(rate_count(config.orders, rate)):
# MAGIC             next_no += 1
# MAGIC             oid = order_id(next_no)
# MAGIC             rows.append(_random_row(rng, config, oid, rng.choice(pharmacy_ids), "OPEN"))
# MAGIC             scenarios[oid] = kind
# MAGIC
# MAGIC     # --- invalid: order rows with a missing order_id
# MAGIC     for _ in range(rate_count(config.orders, config.missing_id_pct)):
# MAGIC         row = _random_row(rng, config, "", rng.choice(pharmacy_ids), "OPEN")
# MAGIC         rows.append(row)
# MAGIC         key = f"|{row['pharmacy_id']}|{row['order_time']}"
# MAGIC         manifest.append(entry("orders", BATCH_1, key, MISSING_ORDER_ID, REJECT))
# MAGIC
# MAGIC     return OrdersResult(pd.DataFrame(rows, columns=ORDERS_COLUMNS), scenarios, manifest)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/order_lines.py << 'EOF'
# MAGIC """Order lines: valid lines for every order plus controlled bad line records."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC from dataclasses import dataclass
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import ORDER_LINES_COLUMNS, GeneratorConfig
# MAGIC from data_generator.generators.orders import (
# MAGIC     BAD_QUANTITY_ORDER,
# MAGIC     BATCH_1,
# MAGIC     MISSING_LINE_ID_ORDER,
# MAGIC     UNKNOWN_PHARMACY_ORDER,
# MAGIC )
# MAGIC from data_generator.manifest import (
# MAGIC     MISSING_LINE_ID,
# MAGIC     MISSING_ORDER_ID,
# MAGIC     NONPOSITIVE_QUANTITY,
# MAGIC     REJECT,
# MAGIC     entry,
# MAGIC )
# MAGIC from data_generator.utils.counts import rate_count
# MAGIC from data_generator.utils.ids import line_id, product_id
# MAGIC from data_generator.utils.random_utils import make_rng, weighted_choice
# MAGIC
# MAGIC LINE_COUNT_CHOICES = [1, 2, 3, 4, 5, 6]
# MAGIC LINE_COUNT_WEIGHTS = [28, 32, 22, 12, 4, 2]  # most orders have 1-4 lines
# MAGIC PACK_QUANTITIES = [10, 12, 20, 24, 30, 40, 50, 60, 100, 120, 150, 200]  # all >= 10 so they can be split
# MAGIC BAD_QUANTITIES = [0, -1, -5, -10]
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class OrderLinesResult:
# MAGIC     """Order lines table plus test manifest entries."""
# MAGIC
# MAGIC     order_lines: pd.DataFrame
# MAGIC     manifest: list[dict[str, str]]
# MAGIC
# MAGIC
# MAGIC def _row(oid: str, lid: str, product: str, quantity: int) -> dict[str, object]:
# MAGIC     return {"order_id": oid, "line_id": lid, "product_id": product, "ordered_quantity": quantity}
# MAGIC
# MAGIC
# MAGIC def generate_order_lines(config: GeneratorConfig, scenarios: dict[str, str]) -> OrderLinesResult:
# MAGIC     """Generate order lines for every order in the scenario map."""
# MAGIC     rng = make_rng(config.seed, "order_lines")
# MAGIC     rows: list[dict[str, object]] = []
# MAGIC     manifest: list[dict[str, str]] = []
# MAGIC
# MAGIC     for oid, scenario in scenarios.items():
# MAGIC         if scenario == BAD_QUANTITY_ORDER:
# MAGIC             product = product_id(rng.randint(1, config.products))
# MAGIC             rows.append(_row(oid, line_id(1), product, rng.choice(BAD_QUANTITIES)))
# MAGIC             manifest.append(entry("order_lines", BATCH_1, f"{oid}|{line_id(1)}", NONPOSITIVE_QUANTITY, REJECT))
# MAGIC         elif scenario == MISSING_LINE_ID_ORDER:
# MAGIC             product = product_id(rng.randint(1, config.products))
# MAGIC             rows.append(_row(oid, "", product, rng.choice(PACK_QUANTITIES)))
# MAGIC             manifest.append(entry("order_lines", BATCH_1, f"{oid}|", MISSING_LINE_ID, REJECT))
# MAGIC         else:
# MAGIC             if scenario == UNKNOWN_PHARMACY_ORDER:
# MAGIC                 n_lines = rng.choice([1, 2])
# MAGIC             else:
# MAGIC                 n_lines = weighted_choice(rng, LINE_COUNT_CHOICES, LINE_COUNT_WEIGHTS)
# MAGIC             n_lines = min(n_lines, config.products)
# MAGIC             products = rng.sample(range(1, config.products + 1), n_lines)  # no repeated product in an order
# MAGIC             for idx, p in enumerate(products, start=1):
# MAGIC                 rows.append(_row(oid, line_id(idx), product_id(p), rng.choice(PACK_QUANTITIES)))
# MAGIC
# MAGIC     # Lines whose order_id is missing (line_ids L90, L91, ... keep each key unique)
# MAGIC     for k in range(rate_count(config.orders, config.missing_id_pct)):
# MAGIC         lid = line_id(90 + k)
# MAGIC         product = product_id(rng.randint(1, config.products))
# MAGIC         rows.append(_row("", lid, product, rng.choice(PACK_QUANTITIES)))
# MAGIC         manifest.append(entry("order_lines", BATCH_1, f"|{lid}", MISSING_ORDER_ID, REJECT))
# MAGIC
# MAGIC     return OrderLinesResult(pd.DataFrame(rows, columns=ORDER_LINES_COLUMNS), manifest)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/shipments.py << 'EOF'
# MAGIC """Shipment lines, built from a per-line shipment plan.
# MAGIC
# MAGIC The plan is the link between shipments and delivery events. Wave 0 shipments
# MAGIC belong to the initial load (batch_001); wave 1 shipments are follow-ups that
# MAGIC arrive in later batches. Cancelled orders and invalid-record orders get no
# MAGIC shipments.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import random
# MAGIC from dataclasses import dataclass
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import SHIPMENT_LINES_COLUMNS, GeneratorConfig
# MAGIC from data_generator.generators.orders import LATE, ON_TIME, OPEN
# MAGIC from data_generator.utils.counts import rate_count, split_quantity
# MAGIC from data_generator.utils.ids import shipment_id
# MAGIC from data_generator.utils.random_utils import make_rng
# MAGIC
# MAGIC PLAN_COLUMNS = SHIPMENT_LINES_COLUMNS + ["scenario", "wave", "ordered_quantity", "overdelivery"]
# MAGIC MULTI_SHIPMENT_PROB = 0.25  # share of on-time orders split into two shipments
# MAGIC LATE_EXTRA_LINE_PROB = 0.4  # chance each extra line of a late order is also late
# MAGIC OPEN_LINE_SHIPPED_PROB = 0.7
# MAGIC OPEN_FOLLOW_UP_PROB = 0.4
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class ShipmentsResult:
# MAGIC     """shipment_lines is the output table; plan carries internal planning columns."""
# MAGIC
# MAGIC     shipment_lines: pd.DataFrame
# MAGIC     plan: pd.DataFrame
# MAGIC
# MAGIC
# MAGIC class _ShipmentCounter:
# MAGIC     def __init__(self) -> None:
# MAGIC         self.n = 0
# MAGIC
# MAGIC     def next(self) -> str:
# MAGIC         self.n += 1
# MAGIC         return shipment_id(self.n)
# MAGIC
# MAGIC
# MAGIC def _row(sid: str, oid: str, lid: str, shipped: int, scenario: str, wave: int, ordered: int,
# MAGIC          over: bool = False) -> dict[str, object]:
# MAGIC     return {
# MAGIC         "shipment_id": sid,
# MAGIC         "order_id": oid,
# MAGIC         "line_id": lid,
# MAGIC         "shipped_quantity": shipped,
# MAGIC         "scenario": scenario,
# MAGIC         "wave": wave,
# MAGIC         "ordered_quantity": ordered,
# MAGIC         "overdelivery": over,
# MAGIC     }
# MAGIC
# MAGIC
# MAGIC def _valid_lines_by_order(order_lines: pd.DataFrame) -> dict[str, list[tuple[str, int]]]:
# MAGIC     """Only well-formed lines can be shipped."""
# MAGIC     ok = order_lines[
# MAGIC         (order_lines["order_id"] != "") & (order_lines["line_id"] != "") & (order_lines["ordered_quantity"] > 0)
# MAGIC     ]
# MAGIC     result: dict[str, list[tuple[str, int]]] = {}
# MAGIC     for oid, group in ok.groupby("order_id", sort=True):
# MAGIC         result[str(oid)] = [(str(lid), int(q)) for lid, q in zip(group["line_id"], group["ordered_quantity"])]
# MAGIC     return result
# MAGIC
# MAGIC
# MAGIC def _pick_overdelivery_orders(rng: random.Random, config: GeneratorConfig, scenarios: dict[str, str]) -> set[str]:
# MAGIC     on_time_ids = sorted(o for o, s in scenarios.items() if s == ON_TIME)
# MAGIC     n = min(len(on_time_ids), rate_count(config.orders, config.overdelivery_pct))
# MAGIC     return set(rng.sample(on_time_ids, n))
# MAGIC
# MAGIC
# MAGIC def _plan_on_time(rng: random.Random, counter: _ShipmentCounter, oid: str,
# MAGIC                   lines: list[tuple[str, int]], over_line: str | None) -> list[dict[str, object]]:
# MAGIC     """All lines fully shipped in wave 0, optionally split over two shipments."""
# MAGIC     rows = []
# MAGIC     split = rng.random() < MULTI_SHIPMENT_PROB
# MAGIC     s1 = counter.next()
# MAGIC     s2 = counter.next() if split else None
# MAGIC     for lid, qty in lines:
# MAGIC         extra = max(1, qty // 5) if lid == over_line else 0  # +20%: raw overdelivery
# MAGIC         if split:
# MAGIC             first = split_quantity(rng, qty)
# MAGIC             rows.append(_row(s1, oid, lid, first, ON_TIME, 0, qty))
# MAGIC             rows.append(_row(s2, oid, lid, qty - first + extra, ON_TIME, 0, qty, extra > 0))
# MAGIC         else:
# MAGIC             rows.append(_row(s1, oid, lid, qty + extra, ON_TIME, 0, qty, extra > 0))
# MAGIC     return rows
# MAGIC
# MAGIC
# MAGIC def _plan_late(rng: random.Random, counter: _ShipmentCounter, oid: str,
# MAGIC                lines: list[tuple[str, int]]) -> list[dict[str, object]]:
# MAGIC     """At least one line is shipped in two waves; its remainder arrives after the promise."""
# MAGIC     rows = []
# MAGIC     late_idx = rng.randrange(len(lines))  # guarantees the order is late
# MAGIC     s0 = counter.next()
# MAGIC     s1 = counter.next()
# MAGIC     for i, (lid, qty) in enumerate(lines):
# MAGIC         if i == late_idx or rng.random() < LATE_EXTRA_LINE_PROB:
# MAGIC             first = split_quantity(rng, qty, 0.4, 0.8)
# MAGIC             rows.append(_row(s0, oid, lid, first, LATE, 0, qty))
# MAGIC             rows.append(_row(s1, oid, lid, qty - first, LATE, 1, qty))
# MAGIC         else:
# MAGIC             rows.append(_row(s0, oid, lid, qty, LATE, 0, qty))
# MAGIC     return rows
# MAGIC
# MAGIC
# MAGIC def _plan_open(rng: random.Random, counter: _ShipmentCounter, oid: str,
# MAGIC                lines: list[tuple[str, int]]) -> list[dict[str, object]]:
# MAGIC     """Partial shipments only: the order can never complete, so open units remain."""
# MAGIC     rows = []
# MAGIC     chosen = [rng.random() < OPEN_LINE_SHIPPED_PROB for _ in lines]
# MAGIC     if not any(chosen):
# MAGIC         chosen[rng.randrange(len(lines))] = True  # at least one line ships something
# MAGIC     s0 = counter.next()
# MAGIC     remaining: list[tuple[str, int, int]] = []
# MAGIC     for (lid, qty), ship in zip(lines, chosen):
# MAGIC         part = split_quantity(rng, qty, 0.3, 0.8) if ship else 0
# MAGIC         if part:
# MAGIC             rows.append(_row(s0, oid, lid, part, OPEN, 0, qty))
# MAGIC         remaining.append((lid, qty, qty - part))
# MAGIC
# MAGIC     if rng.random() < OPEN_FOLLOW_UP_PROB:
# MAGIC         follow_up = []
# MAGIC         for lid, qty, rest in remaining:
# MAGIC             if rest >= 2:
# MAGIC                 follow_up.append((lid, qty, rng.randint(1, rest // 2)))  # never completes the line
# MAGIC         if follow_up:
# MAGIC             s1 = counter.next()
# MAGIC             for lid, qty, shipped in follow_up:
# MAGIC                 rows.append(_row(s1, oid, lid, shipped, OPEN, 1, qty))
# MAGIC     return rows
# MAGIC
# MAGIC
# MAGIC def generate_shipments(config: GeneratorConfig, order_lines: pd.DataFrame,
# MAGIC                        scenarios: dict[str, str]) -> ShipmentsResult:
# MAGIC     """Generate shipment lines for on_time, late and open orders."""
# MAGIC     rng = make_rng(config.seed, "shipments")
# MAGIC     counter = _ShipmentCounter()
# MAGIC     lines_by_order = _valid_lines_by_order(order_lines)
# MAGIC     over_orders = _pick_overdelivery_orders(rng, config, scenarios)
# MAGIC
# MAGIC     rows: list[dict[str, object]] = []
# MAGIC     for oid in sorted(lines_by_order):
# MAGIC         scenario = scenarios.get(oid)
# MAGIC         lines = lines_by_order[oid]
# MAGIC         if scenario == ON_TIME:
# MAGIC             over_line = rng.choice(lines)[0] if oid in over_orders else None
# MAGIC             rows.extend(_plan_on_time(rng, counter, oid, lines, over_line))
# MAGIC         elif scenario == LATE:
# MAGIC             rows.extend(_plan_late(rng, counter, oid, lines))
# MAGIC         elif scenario == OPEN:
# MAGIC             rows.extend(_plan_open(rng, counter, oid, lines))
# MAGIC
# MAGIC     plan = pd.DataFrame(rows, columns=PLAN_COLUMNS)
# MAGIC     plan = plan.sort_values(["shipment_id", "line_id"]).reset_index(drop=True)
# MAGIC     return ShipmentsResult(plan[SHIPMENT_LINES_COLUMNS].copy(), plan)
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC PYTHONPATH=src python - << 'EOF'
# MAGIC import pandas as pd
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.generators.pharmacies import generate_pharmacies
# MAGIC from data_generator.generators.orders import generate_orders
# MAGIC from data_generator.generators.order_lines import generate_order_lines
# MAGIC from data_generator.generators.shipments import generate_shipments
# MAGIC
# MAGIC def build(cfg):
# MAGIC     ph = generate_pharmacies(cfg)
# MAGIC     o = generate_orders(cfg, ph["pharmacy_id"].tolist())
# MAGIC     ol = generate_order_lines(cfg, o.scenarios)
# MAGIC     sh = generate_shipments(cfg, ol.order_lines, o.scenarios)
# MAGIC     return ph, o, ol, sh
# MAGIC
# MAGIC cfg = GeneratorConfig()
# MAGIC ph, o, ol, sh = build(cfg)
# MAGIC
# MAGIC print("rows  pharmacies/orders/order_lines/shipment_lines:",
# MAGIC       len(ph), len(o.orders), len(ol.order_lines), len(sh.shipment_lines))
# MAGIC print("scenarios:", pd.Series(o.scenarios).value_counts().to_dict())
# MAGIC print("manifest entries:", len(o.manifest) + len(ol.manifest))
# MAGIC print(sh.plan.groupby(["scenario", "wave"]).size().to_string())
# MAGIC
# MAGIC # every shipment line must reference an exact, valid order line
# MAGIC m = sh.shipment_lines.merge(ol.order_lines[["order_id", "line_id"]], on=["order_id", "line_id"],
# MAGIC                             how="left", indicator=True)
# MAGIC print("orphan shipment lines (expect 0):", int((m["_merge"] != "both").sum()))
# MAGIC print("overdelivery lines:", int(sh.plan["overdelivery"].sum()))
# MAGIC
# MAGIC # determinism: same seed -> identical frames
# MAGIC _, o2, ol2, sh2 = build(GeneratorConfig())
# MAGIC print("deterministic:", o.orders.equals(o2.orders) and ol.order_lines.equals(ol2.order_lines)
# MAGIC       and sh.shipment_lines.equals(sh2.shipment_lines))
# MAGIC
# MAGIC # different seed -> different data
# MAGIC _, o3, _, _ = build(GeneratorConfig(seed=7))
# MAGIC print("different seed differs:", not o.orders.equals(o3.orders))
# MAGIC print(o.orders.head(3).to_string(index=False))
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/delivery_events.py << 'EOF'
# MAGIC """Delivery events: incremental delivered quantities, split across batches.
# MAGIC
# MAGIC Each valid shipment line produces exactly one valid delivery event whose
# MAGIC delivered_quantity equals the shipped quantity. Events are INCREMENTAL, never
# MAGIC cumulative. Final waves decide the batch:
# MAGIC
# MAGIC * wave 0 shipments            -> batch_001 (before the promised time)
# MAGIC * wave 1 shipments (follow-up) -> batch_002 / batch_003 (after the promised time)
# MAGIC
# MAGIC Incremental batches are capped at config.incremental_batch_max events. Late
# MAGIC follow-ups always fit (otherwise a ValueError explains how to fix the config).
# MAGIC Open-order follow-ups that do not fit are demoted into batch_001.
# MAGIC
# MAGIC Bad events are ADDITIONAL rows (never edits of valid ones) and are recorded in
# MAGIC the test manifest, not in the CSV schema.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import random
# MAGIC from dataclasses import dataclass
# MAGIC from datetime import datetime, timedelta
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator import manifest as mf
# MAGIC from data_generator.config import DELIVERY_EVENTS_COLUMNS, GeneratorConfig
# MAGIC from data_generator.generators.orders import LATE, OPEN
# MAGIC from data_generator.utils.counts import rate_count
# MAGIC from data_generator.utils.ids import event_id, shipment_id
# MAGIC from data_generator.utils.random_utils import format_ts, make_rng, parse_ts
# MAGIC
# MAGIC # Internal event kinds (never written to CSV)
# MAGIC VALID = "valid"
# MAGIC EARLY = "early_delivery"
# MAGIC NEGATIVE = "negative_delivery"
# MAGIC UNKNOWN_SHIPMENT = "unknown_shipment"
# MAGIC MISSING_ORDER = "missing_order_id"
# MAGIC MISSING_LINE = "missing_line_id"
# MAGIC DUPLICATE = "duplicate"
# MAGIC
# MAGIC UNKNOWN_SHIPMENT_START = 900000  # unknown shipment IDs are SHP-900001 and up
# MAGIC HOUR = 3600
# MAGIC
# MAGIC _KIND_MANIFEST = {
# MAGIC     EARLY: (mf.DELIVERY_BEFORE_ORDER, mf.FLAG),
# MAGIC     NEGATIVE: (mf.NEGATIVE_DELIVERY, mf.REJECT),
# MAGIC     UNKNOWN_SHIPMENT: (mf.UNKNOWN_SHIPMENT_LINE, mf.QUARANTINE),
# MAGIC     MISSING_ORDER: (mf.MISSING_ORDER_ID, mf.REJECT),
# MAGIC     MISSING_LINE: (mf.MISSING_LINE_ID, mf.REJECT),
# MAGIC     DUPLICATE: (mf.DUPLICATE_EVENT_ID, mf.DEDUPLICATE),
# MAGIC }
# MAGIC
# MAGIC
# MAGIC def batch_name(index: int) -> str:
# MAGIC     """Zero-based batch index -> 'batch_001', 'batch_002', ..."""
# MAGIC     return f"batch_{index + 1:03d}"
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class _Event:
# MAGIC     """Internal event record. kind and source never reach the CSV."""
# MAGIC
# MAGIC     shipment_id: str
# MAGIC     order_id: str
# MAGIC     line_id: str
# MAGIC     quantity: int
# MAGIC     time: datetime
# MAGIC     batch: int
# MAGIC     kind: str
# MAGIC     source: "_Event | None" = None
# MAGIC     event_id: str = ""
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class DeliveryEventsResult:
# MAGIC     """Delivery event frames keyed by batch name, plus test manifest entries."""
# MAGIC
# MAGIC     batches: dict[str, pd.DataFrame]
# MAGIC     manifest: list[dict[str, str]]
# MAGIC
# MAGIC
# MAGIC def _order_timing(orders: pd.DataFrame) -> dict[str, tuple[datetime, datetime]]:
# MAGIC     """order_id -> (order_time, promised_delivery_time) for well-formed orders."""
# MAGIC     ok = orders[orders["order_id"] != ""]
# MAGIC     return {
# MAGIC         str(o): (parse_ts(ot), parse_ts(pt))
# MAGIC         for o, ot, pt in zip(ok["order_id"], ok["order_time"], ok["promised_delivery_time"])
# MAGIC     }
# MAGIC
# MAGIC
# MAGIC def _assign_followups(rng: random.Random, plan: pd.DataFrame, n_inc: int, cap: int) -> dict[str, int]:
# MAGIC     """Map order_id -> incremental batch index (1..n_inc) for wave-1 events.
# MAGIC
# MAGIC     Late orders are placed first and must fit. Open-order follow-ups are placed
# MAGIC     while there is capacity; the rest are demoted (absent from the result).
# MAGIC     """
# MAGIC     if n_inc == 0:
# MAGIC         return {}
# MAGIC     wave1 = plan[plan["wave"] == 1]
# MAGIC     sizes = wave1.groupby("order_id").size()
# MAGIC     scenario = wave1.groupby("order_id")["scenario"].first()
# MAGIC     late_orders = sorted(str(o) for o in sizes.index if scenario[o] == LATE)
# MAGIC     open_orders = sorted(str(o) for o in sizes.index if scenario[o] == OPEN)
# MAGIC     rng.shuffle(late_orders)
# MAGIC     rng.shuffle(open_orders)
# MAGIC
# MAGIC     loads = [0] * (n_inc + 1)  # index 0 unused
# MAGIC     assignment: dict[str, int] = {}
# MAGIC
# MAGIC     def least_loaded() -> int:
# MAGIC         return min(range(1, n_inc + 1), key=lambda b: (loads[b], b))
# MAGIC
# MAGIC     for oid in late_orders:
# MAGIC         size = int(sizes[oid])
# MAGIC         b = least_loaded()
# MAGIC         if loads[b] + size > cap:
# MAGIC             raise ValueError(
# MAGIC                 "Too many late follow-up events for the incremental batch limit. "
# MAGIC                 "Reduce --orders, raise --incremental-batch-max, or raise --batches."
# MAGIC             )
# MAGIC         loads[b] += size
# MAGIC         assignment[oid] = b
# MAGIC     for oid in open_orders:
# MAGIC         size = int(sizes[oid])
# MAGIC         b = least_loaded()
# MAGIC         if loads[b] + size <= cap:
# MAGIC             loads[b] += size
# MAGIC             assignment[oid] = b
# MAGIC     return assignment
# MAGIC
# MAGIC
# MAGIC def _shipment_times(rng: random.Random, plan: pd.DataFrame,
# MAGIC                     timing: dict[str, tuple[datetime, datetime]],
# MAGIC                     post_promise: set[str]) -> dict[str, datetime]:
# MAGIC     """One delivery time per shipment.
# MAGIC
# MAGIC     Wave-1 shipments of orders in post_promise arrive 6-48 hours AFTER the
# MAGIC     promised time. Everything else arrives before it (at least 1 hour early).
# MAGIC     """
# MAGIC     times: dict[str, datetime] = {}
# MAGIC     shipments = plan.drop_duplicates("shipment_id")[["shipment_id", "order_id", "wave"]]
# MAGIC     for sid, oid, wave in zip(shipments["shipment_id"], shipments["order_id"], shipments["wave"]):
# MAGIC         order_time, promised = timing[str(oid)]
# MAGIC         if int(wave) == 1 and oid in post_promise:
# MAGIC             times[str(sid)] = promised + timedelta(seconds=rng.randint(6 * HOUR, 48 * HOUR))
# MAGIC         else:
# MAGIC             lead = int((promised - order_time).total_seconds())
# MAGIC             times[str(sid)] = order_time + timedelta(seconds=rng.randint(6 * HOUR, lead - HOUR))
# MAGIC     return times
# MAGIC
# MAGIC
# MAGIC def _valid_events(plan: pd.DataFrame, followups: dict[str, int], times: dict[str, datetime]) -> list[_Event]:
# MAGIC     """One valid event per shipment line."""
# MAGIC     events = []
# MAGIC     for r in plan.itertuples(index=False):
# MAGIC         batch = followups.get(r.order_id, 0) if int(r.wave) == 1 else 0
# MAGIC         events.append(
# MAGIC             _Event(r.shipment_id, r.order_id, r.line_id, int(r.shipped_quantity), times[r.shipment_id], batch, VALID)
# MAGIC         )
# MAGIC     return events
# MAGIC
# MAGIC
# MAGIC def _make_specials(rng: random.Random, config: GeneratorConfig, base: list,
# MAGIC                    timing: dict[str, tuple[datetime, datetime]], n_valid: int) -> list[_Event]:
# MAGIC     """Extra bad events built on top of existing on-time shipment lines."""
# MAGIC     if not base:
# MAGIC         return []
# MAGIC     out: list[_Event] = []
# MAGIC
# MAGIC     def valid_time(order_time: datetime) -> datetime:
# MAGIC         return order_time + timedelta(seconds=rng.randint(6 * HOUR, 40 * HOUR))
# MAGIC
# MAGIC     for _ in range(rate_count(n_valid, config.early_delivery_pct)):
# MAGIC         r = rng.choice(base)
# MAGIC         order_time = timing[r.order_id][0]
# MAGIC         t = order_time - timedelta(seconds=rng.randint(HOUR, 72 * HOUR))  # before order creation
# MAGIC         out.append(_Event(r.shipment_id, r.order_id, r.line_id, rng.randint(1, 5), t, 0, EARLY))
# MAGIC
# MAGIC     for _ in range(rate_count(n_valid, config.negative_delivery_pct)):
# MAGIC         r = rng.choice(base)
# MAGIC         t = valid_time(timing[r.order_id][0])
# MAGIC         out.append(_Event(r.shipment_id, r.order_id, r.line_id, -rng.randint(1, 20), t, 0, NEGATIVE))
# MAGIC
# MAGIC     for k in range(rate_count(n_valid, config.unknown_shipment_pct)):
# MAGIC         r = rng.choice(base)
# MAGIC         t = valid_time(timing[r.order_id][0])
# MAGIC         if k % 2 == 0:  # shipment_id does not exist at all
# MAGIC             sid, lid = shipment_id(UNKNOWN_SHIPMENT_START + k + 1), r.line_id
# MAGIC         else:  # real shipment, but it has no line L09
# MAGIC             sid, lid = r.shipment_id, "L09"
# MAGIC         out.append(_Event(sid, r.order_id, lid, rng.randint(1, 50), t, 0, UNKNOWN_SHIPMENT))
# MAGIC
# MAGIC     for k in range(rate_count(n_valid, config.missing_id_pct)):
# MAGIC         r = rng.choice(base)
# MAGIC         t = valid_time(timing[r.order_id][0])
# MAGIC         if k % 2 == 0:
# MAGIC             out.append(_Event(r.shipment_id, "", r.line_id, int(r.shipped_quantity), t, 0, MISSING_ORDER))
# MAGIC         else:
# MAGIC             out.append(_Event(r.shipment_id, r.order_id, "", int(r.shipped_quantity), t, 0, MISSING_LINE))
# MAGIC     return out
# MAGIC
# MAGIC
# MAGIC def _clone(src: _Event, batch: int = 0) -> _Event:
# MAGIC     """An exact replay of an existing event (same event_id once IDs are assigned)."""
# MAGIC     return _Event(src.shipment_id, src.order_id, src.line_id, src.quantity, src.time, batch, DUPLICATE, source=src)
# MAGIC
# MAGIC
# MAGIC def _make_duplicates(rng: random.Random, config: GeneratorConfig, valid: list[_Event]) -> list[_Event]:
# MAGIC     """Duplicates only copy batch_001 events, so the original always arrives first."""
# MAGIC     sources = [e for e in valid if e.batch == 0]
# MAGIC     n = min(len(sources), rate_count(len(valid), config.duplicate_event_pct))
# MAGIC     return [_clone(e) for e in rng.sample(sources, n)]
# MAGIC
# MAGIC
# MAGIC def _place_specials(rng: random.Random, config: GeneratorConfig, valid: list[_Event],
# MAGIC                     pool: list[_Event]) -> list[_Event]:
# MAGIC     """Fill each incremental batch up to a random target size using bad events.
# MAGIC
# MAGIC     Leftover bad events stay in batch_001. If the pool runs out before the
# MAGIC     batch reaches its minimum size, replayed duplicates pad it. Returns padding.
# MAGIC     """
# MAGIC     pool = list(pool)
# MAGIC     rng.shuffle(pool)
# MAGIC     padding: list[_Event] = []
# MAGIC     base = [e for e in valid if e.batch == 0]
# MAGIC     for b in range(1, config.batches):
# MAGIC         current = sum(1 for e in valid if e.batch == b)
# MAGIC         target = rng.randint(max(current, config.incremental_batch_min), config.incremental_batch_max)
# MAGIC         need = target - current
# MAGIC         take = pool[:need]
# MAGIC         del pool[:need]
# MAGIC         for e in take:
# MAGIC             e.batch = b
# MAGIC         shortfall = need - len(take)
# MAGIC         if shortfall > 0 and not base:
# MAGIC             raise ValueError("Not enough events to fill an incremental batch; increase --orders.")
# MAGIC         for _ in range(shortfall):
# MAGIC             padding.append(_clone(rng.choice(base), batch=b))
# MAGIC     return padding
# MAGIC
# MAGIC
# MAGIC def _assign_event_ids(events: list[_Event]) -> None:
# MAGIC     """Number non-duplicate events in (batch, time) order; duplicates copy their original's ID."""
# MAGIC     originals = [e for e in events if e.source is None]
# MAGIC     originals.sort(key=lambda e: (e.batch, e.time, e.shipment_id, e.order_id, e.line_id, e.kind))
# MAGIC     for n, e in enumerate(originals, start=1):
# MAGIC         e.event_id = event_id(n)
# MAGIC     for e in events:
# MAGIC         if e.source is not None:
# MAGIC             e.event_id = e.source.event_id
# MAGIC
# MAGIC
# MAGIC def _to_frame(events: list[_Event]) -> pd.DataFrame:
# MAGIC     ordered = sorted(events, key=lambda e: (e.time, e.event_id, e.source is not None))
# MAGIC     rows = [
# MAGIC         {
# MAGIC             "event_id": e.event_id,
# MAGIC             "shipment_id": e.shipment_id,
# MAGIC             "order_id": e.order_id,
# MAGIC             "line_id": e.line_id,
# MAGIC             "delivered_quantity": e.quantity,
# MAGIC             "delivery_time": format_ts(e.time),
# MAGIC         }
# MAGIC         for e in ordered
# MAGIC     ]
# MAGIC     return pd.DataFrame(rows, columns=DELIVERY_EVENTS_COLUMNS)
# MAGIC
# MAGIC
# MAGIC def _manifest_entries(events: list[_Event], plan: pd.DataFrame) -> list[dict[str, str]]:
# MAGIC     entries = []
# MAGIC     for e in events:
# MAGIC         if e.kind in _KIND_MANIFEST:
# MAGIC             reason, treatment = _KIND_MANIFEST[e.kind]
# MAGIC             entries.append(mf.entry("delivery_events", batch_name(e.batch), e.event_id, reason, treatment))
# MAGIC     over = plan[plan["overdelivery"]]
# MAGIC     for oid, lid in zip(over["order_id"], over["line_id"]):
# MAGIC         entries.append(mf.entry("delivery_events", batch_name(0), f"{oid}|{lid}", mf.OVERDELIVERY, mf.FLAG))
# MAGIC     return entries
# MAGIC
# MAGIC
# MAGIC def generate_delivery_events(config: GeneratorConfig, orders: pd.DataFrame,
# MAGIC                              plan: pd.DataFrame) -> DeliveryEventsResult:
# MAGIC     """Generate delivery events for every batch."""
# MAGIC     rng = make_rng(config.seed, "delivery_events")
# MAGIC     n_inc = config.batches - 1
# MAGIC     cap = config.incremental_batch_max - max(1, config.incremental_batch_max // 10)
# MAGIC
# MAGIC     timing = _order_timing(orders)
# MAGIC     followups = _assign_followups(rng, plan, n_inc, cap)
# MAGIC     if n_inc == 0:  # single batch: follow-ups still arrive late, but in batch_001
# MAGIC         post_promise = set(plan.loc[plan["wave"] == 1, "order_id"])
# MAGIC     else:
# MAGIC         post_promise = set(followups)
# MAGIC     times = _shipment_times(rng, plan, timing, post_promise)
# MAGIC     valid = _valid_events(plan, followups, times)
# MAGIC
# MAGIC     base = [r for r in plan.itertuples(index=False) if r.scenario == "on_time" and int(r.wave) == 0]
# MAGIC     specials = _make_specials(rng, config, base, timing, len(valid))
# MAGIC     duplicates = _make_duplicates(rng, config, valid)
# MAGIC     padding = _place_specials(rng, config, valid, specials + duplicates)
# MAGIC
# MAGIC     all_events = valid + specials + duplicates + padding
# MAGIC     _assign_event_ids(all_events)
# MAGIC
# MAGIC     batches = {
# MAGIC         batch_name(b): _to_frame([e for e in all_events if e.batch == b]) for b in range(config.batches)
# MAGIC     }
# MAGIC     return DeliveryEventsResult(batches, _manifest_entries(all_events, plan))
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/generators/fixtures.py << 'EOF'
# MAGIC """Known-result fixture: a handful of orders with hand-computed expected results.
# MAGIC
# MAGIC Everything here is typed in by hand. No code computes the expected values, so
# MAGIC the expected_results table is an independent oracle for the future Gold layer.
# MAGIC
# MAGIC Assumed report as-of time: 2026-10-01T00:00:00Z (after every promised time).
# MAGIC
# MAGIC Scenarios (all IDs use the FX- prefix):
# MAGIC
# MAGIC FX-ORD-000001  partial delivery     100 ordered, 60 delivered on time, 40 never arrive
# MAGIC FX-ORD-000002  late completion      60 on time, 40 one day after the promise
# MAGIC FX-ORD-000003  two lines            L01 (50) on time, L02 (30) one day late
# MAGIC FX-ORD-000004  cancelled            excluded from the OTIF denominator
# MAGIC FX-ORD-000005  replay               one 100-unit event delivered on time, listed TWICE
# MAGIC FX-ORD-000006  overdelivery         100 ordered, 120 delivered on time
# MAGIC
# MAGIC Assumption: a cancelled order contributes 0 open units (it is no longer expected to ship).
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC from dataclasses import dataclass
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import (
# MAGIC     DELIVERY_EVENTS_COLUMNS,
# MAGIC     EXPECTED_RESULTS_COLUMNS,
# MAGIC     ORDER_LINES_COLUMNS,
# MAGIC     ORDERS_COLUMNS,
# MAGIC     SHIPMENT_LINES_COLUMNS,
# MAGIC )
# MAGIC
# MAGIC FIXTURE_AS_OF = "2026-10-01T00:00:00Z"
# MAGIC
# MAGIC _ORDERS = [
# MAGIC     ("FX-ORD-000001", "PH-0001", "2026-09-01T08:00:00Z", "2026-09-04T08:00:00Z", "OPEN"),
# MAGIC     ("FX-ORD-000002", "PH-0001", "2026-09-01T09:00:00Z", "2026-09-04T09:00:00Z", "COMPLETED"),
# MAGIC     ("FX-ORD-000003", "PH-0001", "2026-09-02T08:00:00Z", "2026-09-05T08:00:00Z", "COMPLETED"),
# MAGIC     ("FX-ORD-000004", "PH-0001", "2026-09-02T10:00:00Z", "2026-09-05T10:00:00Z", "CANCELLED"),
# MAGIC     ("FX-ORD-000005", "PH-0001", "2026-09-03T08:00:00Z", "2026-09-06T08:00:00Z", "COMPLETED"),
# MAGIC     ("FX-ORD-000006", "PH-0001", "2026-09-03T09:00:00Z", "2026-09-06T09:00:00Z", "COMPLETED"),
# MAGIC ]
# MAGIC
# MAGIC _ORDER_LINES = [
# MAGIC     ("FX-ORD-000001", "L01", "PRD-0001", 100),
# MAGIC     ("FX-ORD-000002", "L01", "PRD-0001", 100),
# MAGIC     ("FX-ORD-000003", "L01", "PRD-0001", 50),
# MAGIC     ("FX-ORD-000003", "L02", "PRD-0002", 30),
# MAGIC     ("FX-ORD-000004", "L01", "PRD-0003", 40),
# MAGIC     ("FX-ORD-000005", "L01", "PRD-0001", 100),
# MAGIC     ("FX-ORD-000006", "L01", "PRD-0002", 100),
# MAGIC ]
# MAGIC
# MAGIC _SHIPMENT_LINES = [
# MAGIC     ("FX-SHP-000001", "FX-ORD-000001", "L01", 60),
# MAGIC     ("FX-SHP-000002", "FX-ORD-000002", "L01", 60),
# MAGIC     ("FX-SHP-000003", "FX-ORD-000002", "L01", 40),
# MAGIC     ("FX-SHP-000004", "FX-ORD-000003", "L01", 50),
# MAGIC     ("FX-SHP-000005", "FX-ORD-000003", "L02", 30),
# MAGIC     ("FX-SHP-000006", "FX-ORD-000005", "L01", 100),
# MAGIC     ("FX-SHP-000007", "FX-ORD-000006", "L01", 120),
# MAGIC ]
# MAGIC
# MAGIC # FX-EVT-0000006 appears twice on purpose (replay / duplicate delivery).
# MAGIC _DELIVERY_EVENTS = [
# MAGIC     ("FX-EVT-0000001", "FX-SHP-000001", "FX-ORD-000001", "L01", 60, "2026-09-03T10:00:00Z"),
# MAGIC     ("FX-EVT-0000002", "FX-SHP-000002", "FX-ORD-000002", "L01", 60, "2026-09-03T12:00:00Z"),
# MAGIC     ("FX-EVT-0000003", "FX-SHP-000003", "FX-ORD-000002", "L01", 40, "2026-09-05T09:00:00Z"),
# MAGIC     ("FX-EVT-0000004", "FX-SHP-000004", "FX-ORD-000003", "L01", 50, "2026-09-04T08:00:00Z"),
# MAGIC     ("FX-EVT-0000005", "FX-SHP-000005", "FX-ORD-000003", "L02", 30, "2026-09-06T08:00:00Z"),
# MAGIC     ("FX-EVT-0000006", "FX-SHP-000006", "FX-ORD-000005", "L01", 100, "2026-09-05T08:00:00Z"),
# MAGIC     ("FX-EVT-0000006", "FX-SHP-000006", "FX-ORD-000005", "L01", 100, "2026-09-05T08:00:00Z"),
# MAGIC     ("FX-EVT-0000007", "FX-SHP-000007", "FX-ORD-000006", "L01", 120, "2026-09-05T09:00:00Z"),
# MAGIC ]
# MAGIC
# MAGIC # order_id, fulfilment %, OTIF, open units, overdelivery flag  (hand-computed)
# MAGIC _EXPECTED = [
# MAGIC     ("FX-ORD-000001", 60.0, "FAIL", 40, "false"),
# MAGIC     ("FX-ORD-000002", 100.0, "FAIL", 0, "false"),
# MAGIC     ("FX-ORD-000003", 100.0, "FAIL", 0, "false"),
# MAGIC     ("FX-ORD-000004", 0.0, "EXCLUDED", 0, "false"),
# MAGIC     ("FX-ORD-000005", 100.0, "PASS", 0, "false"),
# MAGIC     ("FX-ORD-000006", 100.0, "PASS", 0, "true"),
# MAGIC ]
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class FixtureData:
# MAGIC     """The five fixture tables."""
# MAGIC
# MAGIC     orders: pd.DataFrame
# MAGIC     order_lines: pd.DataFrame
# MAGIC     shipment_lines: pd.DataFrame
# MAGIC     delivery_events: pd.DataFrame
# MAGIC     expected_results: pd.DataFrame
# MAGIC
# MAGIC
# MAGIC def generate_fixture() -> FixtureData:
# MAGIC     """Return the fixed fixture. It takes no seed because nothing is random."""
# MAGIC     return FixtureData(
# MAGIC         orders=pd.DataFrame(_ORDERS, columns=ORDERS_COLUMNS),
# MAGIC         order_lines=pd.DataFrame(_ORDER_LINES, columns=ORDER_LINES_COLUMNS),
# MAGIC         shipment_lines=pd.DataFrame(_SHIPMENT_LINES, columns=SHIPMENT_LINES_COLUMNS),
# MAGIC         delivery_events=pd.DataFrame(_DELIVERY_EVENTS, columns=DELIVERY_EVENTS_COLUMNS),
# MAGIC         expected_results=pd.DataFrame(_EXPECTED, columns=EXPECTED_RESULTS_COLUMNS),
# MAGIC     )
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC PYTHONPATH=src python - << 'EOF'
# MAGIC import pandas as pd
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.generators.pharmacies import generate_pharmacies
# MAGIC from data_generator.generators.orders import generate_orders
# MAGIC from data_generator.generators.order_lines import generate_order_lines
# MAGIC from data_generator.generators.shipments import generate_shipments
# MAGIC from data_generator.generators.delivery_events import generate_delivery_events
# MAGIC from data_generator.generators.fixtures import generate_fixture
# MAGIC
# MAGIC def build(cfg):
# MAGIC     ph = generate_pharmacies(cfg)
# MAGIC     o = generate_orders(cfg, ph["pharmacy_id"].tolist())
# MAGIC     ol = generate_order_lines(cfg, o.scenarios)
# MAGIC     sh = generate_shipments(cfg, ol.order_lines, o.scenarios)
# MAGIC     de = generate_delivery_events(cfg, o.orders, sh.plan)
# MAGIC     return o, ol, sh, de
# MAGIC
# MAGIC cfg = GeneratorConfig()
# MAGIC o, ol, sh, de = build(cfg)
# MAGIC
# MAGIC print("batch sizes:", {k: len(v) for k, v in de.batches.items()})
# MAGIC m = pd.DataFrame(de.manifest)
# MAGIC print(m.groupby(["reason", "expected_treatment"]).size().to_string())
# MAGIC
# MAGIC allev = pd.concat(de.batches.values(), ignore_index=True)
# MAGIC j = allev.merge(sh.shipment_lines, on=["shipment_id", "order_id", "line_id"], how="left", indicator=True)
# MAGIC unmatched = int((j["_merge"] != "both").sum())
# MAGIC expected_unmatched = int(m["reason"].isin(["unknown_shipment_line", "missing_order_id", "missing_line_id"]).sum()
# MAGIC                          - len(m[(m["dataset"] != "delivery_events")]))
# MAGIC print("events with no shipment line:", unmatched, "| expected from manifest:", expected_unmatched)
# MAGIC
# MAGIC dup_rows = int(allev["event_id"].duplicated().sum())
# MAGIC print("duplicate event_id rows:", dup_rows, "| manifest duplicates:", int((m["reason"] == "duplicate_event_id").sum()))
# MAGIC print("negative quantities:", int((allev["delivered_quantity"] < 0).sum()))
# MAGIC
# MAGIC orders_t = o.orders.set_index("order_id")
# MAGIC early = allev.merge(o.orders, on="order_id")
# MAGIC print("events before order creation:", int((early["delivery_time"] < early["order_time"]).sum()))
# MAGIC
# MAGIC inc = [len(de.batches[b]) for b in ("batch_002", "batch_003")]
# MAGIC print("incremental batches within 100-500:", all(100 <= n <= 500 for n in inc))
# MAGIC
# MAGIC cfg2 = GeneratorConfig()
# MAGIC _, _, _, de2 = build(cfg2)
# MAGIC print("deterministic:", all(de.batches[k].equals(de2.batches[k]) for k in de.batches))
# MAGIC
# MAGIC fx = generate_fixture()
# MAGIC print(fx.expected_results.to_string(index=False))
# MAGIC print("fixture events:", len(fx.delivery_events), "| distinct event_ids:", fx.delivery_events["event_id"].nunique())
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/validation/referential_integrity.py << 'EOF'
# MAGIC """Self-validation of the generated dataset.
# MAGIC
# MAGIC The generator deliberately creates bad records. Validation therefore uses the
# MAGIC test manifest as an answer key:
# MAGIC
# MAGIC * a bad-looking record that IS in the manifest must really show its defect;
# MAGIC * a bad-looking record that is NOT in the manifest is a generator bug.
# MAGIC
# MAGIC Errors fail the run. Warnings (e.g. a bad-record type disabled by setting its
# MAGIC rate to 0) are logged but do not fail it.
# MAGIC """
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC from dataclasses import dataclass, field
# MAGIC
# MAGIC import pandas as pd
# MAGIC from pandas.api.types import is_integer_dtype
# MAGIC
# MAGIC from data_generator import manifest as mf
# MAGIC from data_generator.config import ORDER_STATUSES, SCHEMAS, EXPECTED_RESULTS_COLUMNS
# MAGIC from data_generator.dataset import GeneratedDataset
# MAGIC from data_generator.generators.fixtures import FixtureData
# MAGIC
# MAGIC TIMESTAMP_PATTERN = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z"
# MAGIC EVENT_COLUMNS = SCHEMAS["delivery_events"]
# MAGIC EVENT_KEY = ["shipment_id", "order_id", "line_id"]
# MAGIC
# MAGIC
# MAGIC class GeneratorValidationError(Exception):
# MAGIC     """Raised when the generated data contains an unexpected defect."""
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class ValidationReport:
# MAGIC     """Collects errors and warnings from all checks."""
# MAGIC
# MAGIC     errors: list[str] = field(default_factory=list)
# MAGIC     warnings: list[str] = field(default_factory=list)
# MAGIC     checks_run: int = 0
# MAGIC
# MAGIC     def check(self, condition: bool, message: str) -> bool:
# MAGIC         """Record an error when `condition` is false."""
# MAGIC         self.checks_run += 1
# MAGIC         if not bool(condition):
# MAGIC             self.errors.append(message)
# MAGIC             return False
# MAGIC         return True
# MAGIC
# MAGIC     def warn_unless(self, condition: bool, message: str) -> None:
# MAGIC         """Record a warning when `condition` is false."""
# MAGIC         self.checks_run += 1
# MAGIC         if not bool(condition):
# MAGIC             self.warnings.append(message)
# MAGIC
# MAGIC     @property
# MAGIC     def ok(self) -> bool:
# MAGIC         return not self.errors
# MAGIC
# MAGIC     def raise_if_failed(self) -> None:
# MAGIC         if self.errors:
# MAGIC             shown = "\n  - ".join(self.errors[:20])
# MAGIC             extra = f"\n  ... and {len(self.errors) - 20} more" if len(self.errors) > 20 else ""
# MAGIC             raise GeneratorValidationError(f"{len(self.errors)} validation error(s):\n  - {shown}{extra}")
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- helpers
# MAGIC def _bad_timestamps(series: pd.Series) -> int:
# MAGIC     return int((~series.astype(str).str.fullmatch(TIMESTAMP_PATTERN)).sum())
# MAGIC
# MAGIC
# MAGIC def _manifest_rows(manifest: pd.DataFrame, dataset: str, reason: str) -> pd.DataFrame:
# MAGIC     return manifest[(manifest["dataset"] == dataset) & (manifest["reason"] == reason)]
# MAGIC
# MAGIC
# MAGIC def _all_events(ds: GeneratedDataset) -> pd.DataFrame:
# MAGIC     parts = [df.assign(batch=name) for name, df in ds.delivery_batches.items()]
# MAGIC     return pd.concat(parts, ignore_index=True)
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- schemas
# MAGIC def _check_schemas(r: ValidationReport, ds: GeneratedDataset) -> None:
# MAGIC     named = {
# MAGIC         "pharmacies": ds.pharmacies,
# MAGIC         "orders": ds.orders,
# MAGIC         "order_lines": ds.order_lines,
# MAGIC         "shipment_lines": ds.shipment_lines,
# MAGIC     }
# MAGIC     for name, df in named.items():
# MAGIC         r.check(list(df.columns) == SCHEMAS[name], f"{name}: columns must be exactly {SCHEMAS[name]}")
# MAGIC     for batch, df in ds.delivery_batches.items():
# MAGIC         r.check(list(df.columns) == EVENT_COLUMNS, f"{batch}/delivery_events: columns must be exactly {EVENT_COLUMNS}")
# MAGIC     if not r.ok:
# MAGIC         return
# MAGIC     r.check(is_integer_dtype(ds.order_lines["ordered_quantity"]), "order_lines.ordered_quantity must be integer")
# MAGIC     r.check(is_integer_dtype(ds.shipment_lines["shipped_quantity"]), "shipment_lines.shipped_quantity must be integer")
# MAGIC     for batch, df in ds.delivery_batches.items():
# MAGIC         r.check(is_integer_dtype(df["delivered_quantity"]), f"{batch}: delivered_quantity must be integer")
# MAGIC         r.check(_bad_timestamps(df["delivery_time"]) == 0, f"{batch}: delivery_time must be ISO-8601 UTC (...Z)")
# MAGIC     for col in ("order_time", "promised_delivery_time"):
# MAGIC         r.check(_bad_timestamps(ds.orders[col]) == 0, f"orders.{col} must be ISO-8601 UTC (...Z)")
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- orders
# MAGIC def _check_orders(r: ValidationReport, ds: GeneratedDataset) -> pd.DataFrame:
# MAGIC     """Returns the well-formed orders (non-empty order_id)."""
# MAGIC     o, m = ds.orders, ds.manifest
# MAGIC     pharmacies = ds.pharmacies
# MAGIC     r.check(pharmacies["pharmacy_id"].is_unique, "pharmacies: pharmacy_id must be unique")
# MAGIC     r.check(bool((pharmacies[["region", "contact_name", "contact_email"]] != "").all().all()),
# MAGIC             "pharmacies: region and contact fields must not be empty")
# MAGIC
# MAGIC     missing = o[o["order_id"] == ""]
# MAGIC     r.check(len(missing) == len(_manifest_rows(m, "orders", mf.MISSING_ORDER_ID)),
# MAGIC             "orders: rows with missing order_id must match the manifest exactly")
# MAGIC
# MAGIC     ok = o[o["order_id"] != ""]
# MAGIC     r.check(ok["order_id"].is_unique, "orders: order_id must be unique")
# MAGIC     r.check(bool(ok["order_status"].isin(ORDER_STATUSES).all()), f"orders: order_status must be in {ORDER_STATUSES}")
# MAGIC     r.check(bool((ok["promised_delivery_time"] > ok["order_time"]).all()),
# MAGIC             "orders: promised_delivery_time must be after order_time")
# MAGIC
# MAGIC     known = set(pharmacies["pharmacy_id"])
# MAGIC     unknown = set(ok.loc[~ok["pharmacy_id"].isin(known), "order_id"])
# MAGIC     expected = set(_manifest_rows(m, "orders", mf.UNKNOWN_PHARMACY)["record_key"])
# MAGIC     r.check(unknown == expected, "orders: unknown-pharmacy orders must match the manifest exactly")
# MAGIC     return ok
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- order lines
# MAGIC def _check_order_lines(r: ValidationReport, ds: GeneratedDataset, orders_ok: pd.DataFrame) -> pd.DataFrame:
# MAGIC     """Returns the valid lines (keys present, quantity > 0)."""
# MAGIC     ol, m = ds.order_lines, ds.manifest
# MAGIC
# MAGIC     no_order = ol[ol["order_id"] == ""]
# MAGIC     r.check(len(no_order) == len(_manifest_rows(m, "order_lines", mf.MISSING_ORDER_ID)),
# MAGIC             "order_lines: rows with missing order_id must match the manifest exactly")
# MAGIC     no_line = ol[(ol["order_id"] != "") & (ol["line_id"] == "")]
# MAGIC     r.check(len(no_line) == len(_manifest_rows(m, "order_lines", mf.MISSING_LINE_ID)),
# MAGIC             "order_lines: rows with missing line_id must match the manifest exactly")
# MAGIC
# MAGIC     wellformed = ol[(ol["order_id"] != "") & (ol["line_id"] != "")]
# MAGIC     r.check(not wellformed.duplicated(["order_id", "line_id"]).any(), "order_lines: (order_id, line_id) must be unique")
# MAGIC
# MAGIC     nonpositive = wellformed[wellformed["ordered_quantity"] <= 0]
# MAGIC     found = set(nonpositive["order_id"] + "|" + nonpositive["line_id"])
# MAGIC     expected = set(_manifest_rows(m, "order_lines", mf.NONPOSITIVE_QUANTITY)["record_key"])
# MAGIC     r.check(found == expected, "order_lines: nonpositive quantities must match the manifest exactly")
# MAGIC
# MAGIC     good = wellformed[wellformed["ordered_quantity"] > 0]
# MAGIC     r.check(bool(good["order_id"].isin(set(orders_ok["order_id"])).all()),
# MAGIC             "order_lines: every valid line must reference an existing order")
# MAGIC     r.check(bool(orders_ok["order_id"].isin(set(ol["order_id"])).all()),
# MAGIC             "orders: every order must have at least one order line row")
# MAGIC     return good
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- shipments
# MAGIC def _check_shipment_lines(r: ValidationReport, ds: GeneratedDataset, lines_ok: pd.DataFrame) -> set[tuple[str, str, str]]:
# MAGIC     """Returns the set of (shipment_id, order_id, line_id) keys."""
# MAGIC     sl = ds.shipment_lines
# MAGIC     r.check(not sl.duplicated(EVENT_KEY).any(), "shipment_lines: (shipment_id, order_id, line_id) must be unique")
# MAGIC     r.check(bool((sl["shipped_quantity"] > 0).all()), "shipment_lines: shipped_quantity must be positive")
# MAGIC     line_keys = set(zip(lines_ok["order_id"], lines_ok["line_id"]))
# MAGIC     orphans = sum(k not in line_keys for k in zip(sl["order_id"], sl["line_id"]))
# MAGIC     r.check(orphans == 0, f"shipment_lines: {orphans} row(s) reference a missing order line")
# MAGIC     return set(zip(sl["shipment_id"], sl["order_id"], sl["line_id"]))
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- delivery events
# MAGIC def _check_delivery_events(r: ValidationReport, ds: GeneratedDataset, orders_ok: pd.DataFrame,
# MAGIC                            lines_ok: pd.DataFrame, ship_keys: set[tuple[str, str, str]]) -> None:
# MAGIC     cfg = ds.config
# MAGIC     dm = ds.manifest[ds.manifest["dataset"] == "delivery_events"]
# MAGIC     events = _all_events(ds)
# MAGIC     order_time = dict(zip(orders_ok["order_id"], orders_ok["order_time"]))
# MAGIC
# MAGIC     # --- batches
# MAGIC     r.check(len(ds.delivery_batches) == cfg.batches, "number of delivery batches must equal config.batches")
# MAGIC     names = list(ds.delivery_batches)
# MAGIC     for i, name in enumerate(names):
# MAGIC         size = len(ds.delivery_batches[name])
# MAGIC         r.check(size > 0, f"{name}: batch must not be empty")
# MAGIC         if i > 0:
# MAGIC             r.check(cfg.incremental_batch_min <= size <= cfg.incremental_batch_max,
# MAGIC                     f"{name}: {size} events is outside {cfg.incremental_batch_min}-{cfg.incremental_batch_max}")
# MAGIC
# MAGIC     # --- identifiers and duplicates
# MAGIC     r.check(bool((events["event_id"] != "").all()), "delivery_events: every event needs an event_id")
# MAGIC     is_dup = events["event_id"].duplicated(keep="first")
# MAGIC     firsts, dups = events[~is_dup], events[is_dup]
# MAGIC     r.check(len(dups) == int((dm["reason"] == mf.DUPLICATE_EVENT_ID).sum()),
# MAGIC             "delivery_events: duplicate event_id rows must match the manifest exactly")
# MAGIC     if len(dups):
# MAGIC         lookup = firsts.set_index("event_id")
# MAGIC         same = all(
# MAGIC             bool((dups[c].to_numpy() == lookup.loc[dups["event_id"], c].to_numpy()).all()) for c in EVENT_COLUMNS[1:]
# MAGIC         )
# MAGIC         r.check(same, "delivery_events: duplicates must be exact copies of an earlier event")
# MAGIC
# MAGIC     refs = events.loc[events["order_id"] != "", "order_id"]
# MAGIC     r.check(bool(refs.isin(set(order_time)).all()), "delivery_events: every non-empty order_id must exist in orders")
# MAGIC
# MAGIC     # --- intentional bad events must really be bad
# MAGIC     def ids(reason: str) -> set[str]:
# MAGIC         return set(dm.loc[dm["reason"] == reason, "record_key"])
# MAGIC
# MAGIC     groups = {
# MAGIC         mf.DELIVERY_BEFORE_ORDER: ids(mf.DELIVERY_BEFORE_ORDER),
# MAGIC         mf.NEGATIVE_DELIVERY: ids(mf.NEGATIVE_DELIVERY),
# MAGIC         mf.UNKNOWN_SHIPMENT_LINE: ids(mf.UNKNOWN_SHIPMENT_LINE),
# MAGIC         mf.MISSING_ORDER_ID: ids(mf.MISSING_ORDER_ID),
# MAGIC         mf.MISSING_LINE_ID: ids(mf.MISSING_LINE_ID),
# MAGIC     }
# MAGIC     bad_ids = set().union(*groups.values())
# MAGIC     bad = firsts[firsts["event_id"].isin(bad_ids)]
# MAGIC     r.check(len(bad) == len(bad_ids), "delivery_events: every manifest bad event must exist exactly once")
# MAGIC
# MAGIC     def pick(reason: str) -> pd.DataFrame:
# MAGIC         return firsts[firsts["event_id"].isin(groups[reason])]
# MAGIC
# MAGIC     early = pick(mf.DELIVERY_BEFORE_ORDER)
# MAGIC     r.check(bool((early["delivery_time"] < early["order_id"].map(order_time).fillna("")).all()),
# MAGIC             "bad events: early-delivery events must be earlier than order_time")
# MAGIC     r.check(bool((pick(mf.NEGATIVE_DELIVERY)["delivered_quantity"] < 0).all()),
# MAGIC             "bad events: negative-delivery events must have delivered_quantity < 0")
# MAGIC     unk = pick(mf.UNKNOWN_SHIPMENT_LINE)
# MAGIC     r.check(all(k not in ship_keys for k in zip(unk["shipment_id"], unk["order_id"], unk["line_id"])),
# MAGIC             "bad events: unknown-shipment events must not match any shipment line")
# MAGIC     r.check(bool((pick(mf.MISSING_ORDER_ID)["order_id"] == "").all()), "bad events: missing-order_id events need an empty order_id")
# MAGIC     r.check(bool((pick(mf.MISSING_LINE_ID)["line_id"] == "").all()), "bad events: missing-line_id events need an empty line_id")
# MAGIC
# MAGIC     # --- everything else must be fully valid (otherwise it is a generator bug)
# MAGIC     valid = firsts[~firsts["event_id"].isin(bad_ids)]
# MAGIC     r.check(bool(((valid["order_id"] != "") & (valid["line_id"] != "")).all()), "valid events: order_id and line_id must be present")
# MAGIC     r.check(bool((valid["delivered_quantity"] > 0).all()), "valid events: delivered_quantity must be positive")
# MAGIC     keys = list(zip(valid["shipment_id"], valid["order_id"], valid["line_id"]))
# MAGIC     r.check(all(k in ship_keys for k in keys), "valid events: must reference an existing shipment line")
# MAGIC     mapped = valid["order_id"].map(order_time)
# MAGIC     r.check(bool(mapped.notna().all()), "valid events: must reference an existing order")
# MAGIC     r.check(bool((valid["delivery_time"] >= mapped.fillna("~")).all()), "valid events: delivery_time must not precede order_time")
# MAGIC
# MAGIC     per_shipment = (
# MAGIC         valid.groupby(EVENT_KEY).agg(n=("event_id", "size"), qty=("delivered_quantity", "sum")).reset_index()
# MAGIC     )
# MAGIC     joined = ds.shipment_lines.merge(per_shipment, on=EVENT_KEY, how="left")
# MAGIC     r.check(bool(joined["n"].eq(1).all()), "every shipment line must have exactly one valid delivery event")
# MAGIC     r.check(bool((joined["qty"] == joined["shipped_quantity"]).all()), "valid events: delivered_quantity must equal shipped_quantity")
# MAGIC
# MAGIC     # --- overdelivery must match the manifest exactly
# MAGIC     delivered = valid.groupby(["order_id", "line_id"])["delivered_quantity"].sum().to_frame("delivered")
# MAGIC     ordered = lines_ok.set_index(["order_id", "line_id"])[["ordered_quantity"]]
# MAGIC     both = delivered.join(ordered, how="left")
# MAGIC     over = {f"{o}|{l}" for (o, l) in both.index[both["delivered"] > both["ordered_quantity"]]}
# MAGIC     r.check(over == set(_manifest_rows(ds.manifest, "delivery_events", mf.OVERDELIVERY)["record_key"]),
# MAGIC             "overdelivered lines must match the manifest exactly")
# MAGIC
# MAGIC     # --- incremental batches should touch orders that already exist (warning only)
# MAGIC     valid_b = valid.assign(batch=valid["event_id"].map(firsts.set_index("event_id")["batch"]))
# MAGIC     base_orders = set(valid_b.loc[valid_b["batch"] == names[0], "order_id"])
# MAGIC     for name in names[1:]:
# MAGIC         touches = valid_b[(valid_b["batch"] == name) & valid_b["order_id"].isin(base_orders)]
# MAGIC         r.warn_unless(len(touches) > 0, f"{name}: has no new valid events for orders already seen in {names[0]}")
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- scenario coverage
# MAGIC def _check_scenario_coverage(r: ValidationReport, ds: GeneratedDataset) -> None:
# MAGIC     present = set(ds.manifest["reason"])
# MAGIC     for reason in (mf.UNKNOWN_PHARMACY, mf.MISSING_ORDER_ID, mf.MISSING_LINE_ID, mf.NONPOSITIVE_QUANTITY,
# MAGIC                    mf.NEGATIVE_DELIVERY, mf.UNKNOWN_SHIPMENT_LINE, mf.DUPLICATE_EVENT_ID,
# MAGIC                    mf.DELIVERY_BEFORE_ORDER, mf.OVERDELIVERY):
# MAGIC         r.warn_unless(reason in present, f"scenario coverage: no '{reason}' records were generated")
# MAGIC     if ds.config.cancelled_pct > 0:
# MAGIC         r.check(bool((ds.orders["order_status"] == "CANCELLED").any()), "scenario coverage: cancelled orders must exist")
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- fixture
# MAGIC def _recompute_fixture(fx: FixtureData) -> dict[str, tuple[float, str, int, str]]:
# MAGIC     """Plain re-derivation used ONLY as a typo guard for the hand-typed table."""
# MAGIC     events = fx.delivery_events.drop_duplicates("event_id")
# MAGIC     out: dict[str, tuple[float, str, int, str]] = {}
# MAGIC     for o in fx.orders.itertuples(index=False):
# MAGIC         if o.order_status == "CANCELLED":
# MAGIC             out[o.order_id] = (0.0, "EXCLUDED", 0, "false")
# MAGIC             continue
# MAGIC         ordered_total = capped_total = open_units = 0
# MAGIC         otif, over = True, False
# MAGIC         for l in fx.order_lines[fx.order_lines["order_id"] == o.order_id].itertuples(index=False):
# MAGIC             ev = events[(events["order_id"] == o.order_id) & (events["line_id"] == l.line_id)]
# MAGIC             delivered = int(ev["delivered_quantity"].sum())
# MAGIC             on_time = int(ev.loc[ev["delivery_time"] <= o.promised_delivery_time, "delivered_quantity"].sum())
# MAGIC             ordered_total += l.ordered_quantity
# MAGIC             capped_total += min(delivered, l.ordered_quantity)
# MAGIC             open_units += max(0, l.ordered_quantity - delivered)
# MAGIC             otif = otif and on_time >= l.ordered_quantity
# MAGIC             over = over or delivered > l.ordered_quantity
# MAGIC         out[o.order_id] = (round(100 * capped_total / ordered_total, 2), "PASS" if otif else "FAIL",
# MAGIC                            open_units, "true" if over else "false")
# MAGIC     return out
# MAGIC
# MAGIC
# MAGIC def _check_fixture(r: ValidationReport, fx: FixtureData) -> None:
# MAGIC     tables = {
# MAGIC         "orders": fx.orders, "order_lines": fx.order_lines, "shipment_lines": fx.shipment_lines,
# MAGIC         "delivery_events": fx.delivery_events,
# MAGIC     }
# MAGIC     for name, df in tables.items():
# MAGIC         r.check(list(df.columns) == SCHEMAS[name], f"fixture/{name}: columns must be exactly {SCHEMAS[name]}")
# MAGIC     r.check(list(fx.expected_results.columns) == EXPECTED_RESULTS_COLUMNS, "fixture/expected_results: wrong columns")
# MAGIC     if not r.ok:
# MAGIC         return
# MAGIC
# MAGIC     order_ids = set(fx.orders["order_id"])
# MAGIC     r.check(fx.orders["order_id"].is_unique, "fixture: order_id must be unique")
# MAGIC     r.check(not fx.order_lines.duplicated(["order_id", "line_id"]).any(), "fixture: order line keys must be unique")
# MAGIC     line_keys = set(zip(fx.order_lines["order_id"], fx.order_lines["line_id"]))
# MAGIC     r.check(set(fx.order_lines["order_id"]) <= order_ids, "fixture: order lines must reference fixture orders")
# MAGIC     r.check(set(zip(fx.shipment_lines["order_id"], fx.shipment_lines["line_id"])) <= line_keys,
# MAGIC             "fixture: shipment lines must reference fixture order lines")
# MAGIC     ship_keys = set(zip(fx.shipment_lines["shipment_id"], fx.shipment_lines["order_id"], fx.shipment_lines["line_id"]))
# MAGIC     ev = fx.delivery_events
# MAGIC     r.check(set(zip(ev["shipment_id"], ev["order_id"], ev["line_id"])) <= ship_keys,
# MAGIC             "fixture: delivery events must reference fixture shipment lines")
# MAGIC     r.check(set(fx.expected_results["order_id"]) == order_ids, "fixture: expected_results must cover exactly the fixture orders")
# MAGIC     r.check(int(ev["event_id"].duplicated().sum()) >= 1, "fixture: a replayed (duplicate) event must exist")
# MAGIC     r.check(int(ev.duplicated().sum()) == int(ev["event_id"].duplicated().sum()), "fixture: duplicate events must be exact copies")
# MAGIC     r.check(bool((fx.orders["order_status"] == "CANCELLED").any()), "fixture: a cancelled order must exist")
# MAGIC
# MAGIC     recomputed = _recompute_fixture(fx)
# MAGIC     for row in fx.expected_results.itertuples(index=False):
# MAGIC         pct, otif, open_units, flag = recomputed[row.order_id]
# MAGIC         got = (float(row.expected_fulfilment_percent), row.expected_otif, int(row.expected_open_units), row.expected_overdelivery_flag)
# MAGIC         r.check(abs(got[0] - pct) < 0.01 and got[1:] == (otif, open_units, flag),
# MAGIC                 f"fixture: expected result for {row.order_id} is {got} but re-derivation gives {(pct, otif, open_units, flag)}")
# MAGIC
# MAGIC
# MAGIC # ----------------------------------------------------------------- entry point
# MAGIC def validate_dataset(ds: GeneratedDataset) -> ValidationReport:
# MAGIC     """Run every check and return the report (does not raise)."""
# MAGIC     report = ValidationReport()
# MAGIC     _check_schemas(report, ds)
# MAGIC     if not report.ok:
# MAGIC         return report
# MAGIC     orders_ok = _check_orders(report, ds)
# MAGIC     lines_ok = _check_order_lines(report, ds, orders_ok)
# MAGIC     ship_keys = _check_shipment_lines(report, ds, lines_ok)
# MAGIC     _check_delivery_events(report, ds, orders_ok, lines_ok, ship_keys)
# MAGIC     _check_scenario_coverage(report, ds)
# MAGIC     _check_fixture(report, ds.fixture)
# MAGIC     return report
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/dataset.py << 'EOF'
# MAGIC """Container for everything one generator run produces."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC from dataclasses import dataclass
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.generators.fixtures import FixtureData
# MAGIC
# MAGIC
# MAGIC @dataclass
# MAGIC class GeneratedDataset:
# MAGIC     """All generated tables, in memory, before they are written to disk."""
# MAGIC
# MAGIC     config: GeneratorConfig
# MAGIC     pharmacies: pd.DataFrame
# MAGIC     orders: pd.DataFrame
# MAGIC     order_lines: pd.DataFrame
# MAGIC     shipment_lines: pd.DataFrame
# MAGIC     delivery_batches: dict[str, pd.DataFrame]  # 'batch_001' -> delivery_events frame
# MAGIC     manifest: pd.DataFrame
# MAGIC     fixture: FixtureData
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/writer.py << 'EOF'
# MAGIC """CSV output: file layout, cleanup of old output, checksums and run summary."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import hashlib
# MAGIC import json
# MAGIC import logging
# MAGIC import re
# MAGIC import shutil
# MAGIC from pathlib import Path
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.dataset import GeneratedDataset
# MAGIC
# MAGIC logger = logging.getLogger(__name__)
# MAGIC
# MAGIC GENERATED_DIRS = {"reference", "fixture", "metadata"}
# MAGIC BATCH_DIR = re.compile(r"batch_\d{3}")
# MAGIC INT_COLUMNS = {"ordered_quantity", "shipped_quantity", "delivered_quantity", "expected_open_units"}
# MAGIC FLOAT_COLUMNS = {"expected_fulfilment_percent"}
# MAGIC
# MAGIC
# MAGIC def read_csv_strict(path: Path) -> pd.DataFrame:
# MAGIC     """Read a generated CSV with exact values: strings stay strings, empty stays '', numbers are typed."""
# MAGIC     df = pd.read_csv(path, dtype=str, keep_default_na=False)
# MAGIC     for col in INT_COLUMNS & set(df.columns):
# MAGIC         df[col] = df[col].astype("int64")
# MAGIC     for col in FLOAT_COLUMNS & set(df.columns):
# MAGIC         df[col] = df[col].astype("float64")
# MAGIC     return df
# MAGIC
# MAGIC
# MAGIC def write_csv(df: pd.DataFrame, path: Path) -> None:
# MAGIC     """Write one CSV (UTF-8, LF line endings, no index) creating folders as needed."""
# MAGIC     path.parent.mkdir(parents=True, exist_ok=True)
# MAGIC     df.to_csv(path, index=False, lineterminator="\n", encoding="utf-8")
# MAGIC
# MAGIC
# MAGIC def clean_output(output_dir: Path) -> None:
# MAGIC     """Remove only the folders this generator creates, so reruns never leave stale batches."""
# MAGIC     if not output_dir.exists():
# MAGIC         return
# MAGIC     for child in output_dir.iterdir():
# MAGIC         if child.is_dir() and (child.name in GENERATED_DIRS or BATCH_DIR.fullmatch(child.name)):
# MAGIC             shutil.rmtree(child)
# MAGIC
# MAGIC
# MAGIC def collect_files(ds: GeneratedDataset) -> dict[str, pd.DataFrame]:
# MAGIC     """Map relative output path -> frame, in a fixed order."""
# MAGIC     files: dict[str, pd.DataFrame] = {"reference/pharmacies.csv": ds.pharmacies}
# MAGIC     first = next(iter(ds.delivery_batches))
# MAGIC     files[f"{first}/orders.csv"] = ds.orders
# MAGIC     files[f"{first}/order_lines.csv"] = ds.order_lines
# MAGIC     files[f"{first}/shipment_lines.csv"] = ds.shipment_lines
# MAGIC     for name, frame in ds.delivery_batches.items():
# MAGIC         files[f"{name}/delivery_events.csv"] = frame
# MAGIC     fx = ds.fixture
# MAGIC     files["fixture/orders.csv"] = fx.orders
# MAGIC     files["fixture/order_lines.csv"] = fx.order_lines
# MAGIC     files["fixture/shipment_lines.csv"] = fx.shipment_lines
# MAGIC     files["fixture/delivery_events.csv"] = fx.delivery_events
# MAGIC     files["fixture/expected_results.csv"] = fx.expected_results
# MAGIC     files["metadata/test_manifest.csv"] = ds.manifest
# MAGIC     return files
# MAGIC
# MAGIC
# MAGIC def _sha256(path: Path) -> str:
# MAGIC     return hashlib.sha256(path.read_bytes()).hexdigest()
# MAGIC
# MAGIC
# MAGIC def write_dataset(ds: GeneratedDataset, output_dir: Path) -> list[Path]:
# MAGIC     """Write every CSV plus metadata/run_summary.json. Returns all written paths."""
# MAGIC     files = collect_files(ds)
# MAGIC     clean_output(output_dir)
# MAGIC
# MAGIC     written: list[Path] = []
# MAGIC     row_counts: dict[str, int] = {}
# MAGIC     checksums: dict[str, str] = {}
# MAGIC     for rel, frame in files.items():
# MAGIC         path = output_dir / rel
# MAGIC         write_csv(frame, path)
# MAGIC         written.append(path)
# MAGIC         row_counts[rel] = len(frame)
# MAGIC         checksums[rel] = _sha256(path)
# MAGIC
# MAGIC     config = ds.config.to_dict()
# MAGIC     config.pop("output_dir", None)  # keep the summary identical regardless of where it is written
# MAGIC     summary = {
# MAGIC         "config": config,
# MAGIC         "row_counts": row_counts,
# MAGIC         "manifest_counts": ds.manifest.groupby(["dataset", "reason"]).size().rename("n").reset_index()
# MAGIC         .assign(key=lambda d: d["dataset"] + "/" + d["reason"]).set_index("key")["n"].astype(int).to_dict(),
# MAGIC         "sha256": checksums,
# MAGIC     }
# MAGIC     summary_path = output_dir / "metadata" / "run_summary.json"
# MAGIC     summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
# MAGIC     written.append(summary_path)
# MAGIC     return written
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/pipeline.py << 'EOF'
# MAGIC """Orchestrates one generator run: build -> validate -> reproducibility check -> write."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import logging
# MAGIC
# MAGIC import pandas as pd
# MAGIC
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.dataset import GeneratedDataset
# MAGIC from data_generator.generators.delivery_events import generate_delivery_events
# MAGIC from data_generator.generators.fixtures import generate_fixture
# MAGIC from data_generator.generators.order_lines import generate_order_lines
# MAGIC from data_generator.generators.orders import generate_orders
# MAGIC from data_generator.generators.pharmacies import generate_pharmacies
# MAGIC from data_generator.generators.shipments import generate_shipments
# MAGIC from data_generator.manifest import manifest_frame
# MAGIC from data_generator.validation.referential_integrity import GeneratorValidationError, validate_dataset
# MAGIC from data_generator.writer import write_dataset
# MAGIC
# MAGIC logger = logging.getLogger(__name__)
# MAGIC
# MAGIC
# MAGIC def build_dataset(config: GeneratorConfig) -> GeneratedDataset:
# MAGIC     """Generate every table in memory. Pure function of the config (and its seed)."""
# MAGIC     pharmacies = generate_pharmacies(config)
# MAGIC     orders = generate_orders(config, pharmacies["pharmacy_id"].tolist())
# MAGIC     lines = generate_order_lines(config, orders.scenarios)
# MAGIC     shipments = generate_shipments(config, lines.order_lines, orders.scenarios)
# MAGIC     events = generate_delivery_events(config, orders.orders, shipments.plan)
# MAGIC
# MAGIC     manifest = manifest_frame(orders.manifest + lines.manifest + events.manifest)
# MAGIC     manifest = manifest.sort_values(["dataset", "batch", "reason", "record_key"], kind="mergesort").reset_index(drop=True)
# MAGIC
# MAGIC     return GeneratedDataset(
# MAGIC         config=config,
# MAGIC         pharmacies=pharmacies,
# MAGIC         orders=orders.orders,
# MAGIC         order_lines=lines.order_lines,
# MAGIC         shipment_lines=shipments.shipment_lines,
# MAGIC         delivery_batches=events.batches,
# MAGIC         manifest=manifest,
# MAGIC         fixture=generate_fixture(),
# MAGIC     )
# MAGIC
# MAGIC
# MAGIC def _frames(ds: GeneratedDataset) -> dict[str, pd.DataFrame]:
# MAGIC     frames = {
# MAGIC         "pharmacies": ds.pharmacies,
# MAGIC         "orders": ds.orders,
# MAGIC         "order_lines": ds.order_lines,
# MAGIC         "shipment_lines": ds.shipment_lines,
# MAGIC         "manifest": ds.manifest,
# MAGIC         "fixture/orders": ds.fixture.orders,
# MAGIC         "fixture/order_lines": ds.fixture.order_lines,
# MAGIC         "fixture/shipment_lines": ds.fixture.shipment_lines,
# MAGIC         "fixture/delivery_events": ds.fixture.delivery_events,
# MAGIC         "fixture/expected_results": ds.fixture.expected_results,
# MAGIC     }
# MAGIC     for name, frame in ds.delivery_batches.items():
# MAGIC         frames[f"delivery_events/{name}"] = frame
# MAGIC     return frames
# MAGIC
# MAGIC
# MAGIC def differing_frames(a: GeneratedDataset, b: GeneratedDataset) -> list[str]:
# MAGIC     """Names of frames that differ between two datasets (empty list = identical)."""
# MAGIC     fa, fb = _frames(a), _frames(b)
# MAGIC     names = sorted(set(fa) | set(fb))
# MAGIC     return [n for n in names if n not in fa or n not in fb or not fa[n].equals(fb[n])]
# MAGIC
# MAGIC
# MAGIC def datasets_equal(a: GeneratedDataset, b: GeneratedDataset) -> bool:
# MAGIC     return not differing_frames(a, b)
# MAGIC
# MAGIC
# MAGIC def run(config: GeneratorConfig, check_reproducibility: bool = True) -> GeneratedDataset:
# MAGIC     """Build, validate and write the dataset. Raises GeneratorValidationError on any unexpected defect."""
# MAGIC     logger.info("Generating data (seed=%s, orders=%s, batches=%s)", config.seed, config.orders, config.batches)
# MAGIC     dataset = build_dataset(config)
# MAGIC
# MAGIC     report = validate_dataset(dataset)
# MAGIC     for warning in report.warnings:
# MAGIC         logger.warning(warning)
# MAGIC     report.raise_if_failed()
# MAGIC     logger.info("Validation passed (%d checks, %d warnings)", report.checks_run, len(report.warnings))
# MAGIC
# MAGIC     if check_reproducibility:
# MAGIC         differing = differing_frames(dataset, build_dataset(config))
# MAGIC         if differing:
# MAGIC             raise GeneratorValidationError(f"Output is not reproducible; differing tables: {differing}")
# MAGIC         logger.info("Reproducibility check passed (two independent builds are identical)")
# MAGIC
# MAGIC     paths = write_dataset(dataset, config.output_path)
# MAGIC     logger.info("Wrote %d files under %s", len(paths), config.output_path.resolve())
# MAGIC     for name, frame in dataset.delivery_batches.items():
# MAGIC         logger.info("  %s/delivery_events.csv: %d rows", name, len(frame))
# MAGIC     logger.info("  test manifest entries: %d", len(dataset.manifest))
# MAGIC     return dataset
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > src/data_generator/cli.py << 'EOF'
# MAGIC """Command-line interface."""
# MAGIC from __future__ import annotations
# MAGIC
# MAGIC import argparse
# MAGIC import logging
# MAGIC import sys
# MAGIC
# MAGIC from data_generator.config import GeneratorConfig
# MAGIC from data_generator.pipeline import run
# MAGIC from data_generator.validation.referential_integrity import GeneratorValidationError
# MAGIC
# MAGIC logger = logging.getLogger("data_generator")
# MAGIC _NOT_CONFIG = {"skip_reproducibility_check", "log_level"}
# MAGIC
# MAGIC
# MAGIC def build_parser() -> argparse.ArgumentParser:
# MAGIC     """Build the argument parser. Unset options fall back to GeneratorConfig defaults."""
# MAGIC     d = GeneratorConfig()
# MAGIC     s = argparse.SUPPRESS  # option absent from the namespace unless the user passes it
# MAGIC     p = argparse.ArgumentParser(
# MAGIC         prog="generate_data.py",
# MAGIC         description="Synthetic data generator for the Cencora pharmacy order fulfilment capstone.",
# MAGIC     )
# MAGIC     p.add_argument("--seed", type=int, default=s, help=f"random seed (default: {d.seed})")
# MAGIC     p.add_argument("--pharmacies", type=int, default=s, help=f"number of pharmacies (default: {d.pharmacies})")
# MAGIC     p.add_argument("--products", type=int, default=s, help=f"number of products (default: {d.products})")
# MAGIC     p.add_argument("--orders", type=int, default=s, help=f"number of valid orders (default: {d.orders})")
# MAGIC     p.add_argument("--start-date", default=s, help=f"earliest order date, YYYY-MM-DD (default: {d.start_date})")
# MAGIC     p.add_argument("--end-date", default=s, help=f"latest order date, YYYY-MM-DD (default: {d.end_date})")
# MAGIC     p.add_argument("--batches", type=int, default=s, help=f"number of delivery batches (default: {d.batches})")
# MAGIC     p.add_argument("--incremental-batch-min", type=int, default=s,
# MAGIC                    help=f"min events in batch_002 and later (default: {d.incremental_batch_min})")
# MAGIC     p.add_argument("--incremental-batch-max", type=int, default=s,
# MAGIC                    help=f"max events in batch_002 and later (default: {d.incremental_batch_max})")
# MAGIC     p.add_argument("--output-dir", default=s, help=f"output folder (default: {d.output_dir})")
# MAGIC     for name, default in d.invalid_rates().items():
# MAGIC         p.add_argument("--" + name.replace("_", "-"), dest=name, type=float, default=s,
# MAGIC                        help=f"bad-record rate as a fraction between 0 and 0.2 (default: {default})")
# MAGIC     p.add_argument("--skip-reproducibility-check", action="store_true",
# MAGIC                    help="skip building the dataset a second time to prove it is identical")
# MAGIC     p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
# MAGIC     return p
# MAGIC
# MAGIC
# MAGIC def config_from_args(args: argparse.Namespace) -> GeneratorConfig:
# MAGIC     """Create a validated config from the parsed options."""
# MAGIC     return GeneratorConfig(**{k: v for k, v in vars(args).items() if k not in _NOT_CONFIG})
# MAGIC
# MAGIC
# MAGIC def main(argv: list[str] | None = None) -> int:
# MAGIC     """Entry point. Returns a process exit code."""
# MAGIC     args = build_parser().parse_args(argv)
# MAGIC     logging.basicConfig(level=args.log_level, format="%(levelname)s %(name)s: %(message)s", stream=sys.stdout)
# MAGIC     try:
# MAGIC         config = config_from_args(args)
# MAGIC     except ValueError as exc:
# MAGIC         logger.error("Invalid configuration: %s", exc)
# MAGIC         return 2
# MAGIC     try:
# MAGIC         run(config, check_reproducibility=not args.skip_reproducibility_check)
# MAGIC     except (ValueError, GeneratorValidationError) as exc:
# MAGIC         logger.error("%s", exc)
# MAGIC         return 1
# MAGIC     return 0
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC cat > generate_data.py << 'EOF'
# MAGIC """Run the synthetic data generator:  python generate_data.py --seed 42"""
# MAGIC import sys
# MAGIC from pathlib import Path
# MAGIC
# MAGIC # Allows running without `pip install -e .`
# MAGIC sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
# MAGIC
# MAGIC from data_generator.cli import main  # noqa: E402
# MAGIC
# MAGIC if __name__ == "__main__":
# MAGIC     raise SystemExit(main())
# MAGIC EOF

# COMMAND ----------

# MAGIC %sh
# MAGIC python generate_data.py --seed 42

# COMMAND ----------

# MAGIC %sh
# MAGIC echo "=== files ==="
# MAGIC find output -type f | sort
# MAGIC echo
# MAGIC echo "=== row counts (including header line) ==="
# MAGIC wc -l output/*/*.csv
# MAGIC echo
# MAGIC echo "=== first rows: batch_002/delivery_events.csv ==="
# MAGIC head -4 output/batch_002/delivery_events.csv
# MAGIC echo
# MAGIC echo "=== fixture expected results ==="
# MAGIC cat output/fixture/expected_results.csv
# MAGIC echo
# MAGIC echo "=== reproducibility: second run into another folder, then diff ==="
# MAGIC python generate_data.py --seed 42 --output-dir output_check --skip-reproducibility-check > /dev/null
# MAGIC diff -r output output_check && echo "IDENTICAL: same seed gives byte-identical files"
# MAGIC rm -rf output_check
# MAGIC echo
# MAGIC echo "=== different seed gives different data ==="
# MAGIC python generate_data.py --seed 7 --output-dir output_seed7 --skip-reproducibility-check > /dev/null
# MAGIC diff -q output/batch_001/orders.csv output_seed7/batch_001/orders.csv
# MAGIC rm -rf output_seed7

# COMMAND ----------

