"""Run the synthetic data generator:  python generate_data.py --seed 42"""
import sys
from pathlib import Path

# Allows running without `pip install -e .`
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from data_generator.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
